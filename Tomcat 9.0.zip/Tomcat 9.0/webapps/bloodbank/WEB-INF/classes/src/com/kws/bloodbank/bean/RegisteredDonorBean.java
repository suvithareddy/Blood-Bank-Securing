package com.kws.bloodbank.bean;

public class RegisteredDonorBean {
	private int campid;
	private int inchargeid;
	private String bloodgroup;
	private String samplestatus;
	private int campdonorid;
	private int sampleid;
	private String samplename;
	private String available;
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public int getCampid() {
		return campid;
	}
	public void setCampid(int campid) {
		this.campid = campid;
	}
	public int getInchargeid() {
		return inchargeid;
	}
	public void setInchargeid(int inchargeid) {
		this.inchargeid = inchargeid;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getSamplestatus() {
		return samplestatus;
	}
	public void setSamplestatus(String samplestatus) {
		this.samplestatus = samplestatus;
	}
	public int getCampdonorid() {
		return campdonorid;
	}
	public void setCampdonorid(int campdonorid) {
		this.campdonorid = campdonorid;
	}
	public int getSampleid() {
		return sampleid;
	}
	public void setSampleid(int sampleid) {
		this.sampleid = sampleid;
	}
	public String getSamplename() {
		return samplename;
	}
	public void setSamplename(String samplename) {
		this.samplename = samplename;
	}
	
	
	 	

}
