package com.kws.bloodbank.bean;

public class BloodBankBean {
    private int bid;
	private String bdor;
	private String bcontact;
	private String bcity;
	private String badress;
	private String bname;
	private String blocation;
	private int inchargeId;
    private int did;
    private String donationDate;
    private String expiryDate;
    private String bloodGroup;
    private String sampleName;
    private double count;
    private String status;
    private int drid;
    private String state;
    private String dname;
    private String rname;
    private int rid;
    private String available;
    private int brid;
    private int recipientid;
    private String recipientname;
	public String getRecipientname() {
		return recipientname;
	}
	public void setRecipientname(String recipientname) {
		this.recipientname = recipientname;
	}
	public int getBrid() {
		return brid;
	}
	public void setBrid(int brid) {
		this.brid = brid;
	}
	public int getRecipientid() {
		return recipientid;
	}
	public void setRecipientid(int recipientid) {
		this.recipientid = recipientid;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getDrid() {
		return drid;
	}
	public void setDrid(int drid) {
		this.drid = drid;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public double getCount() {
		return count;
	}
	public void setCount(double count) {
		this.count = count;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBlocation() {
		return blocation;
	}
	public void setBlocation(String blocation) {
		this.blocation = blocation;
	}
	public int getInchargeId() {
		return inchargeId;
	}
	public void setInchargeId(int inchargeId) {
		this.inchargeId = inchargeId;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(String donationDate) {
		this.donationDate = donationDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getSampleName() {
		return sampleName;
	}
	public void setSampleName(String sampleName) {
		this.sampleName = sampleName;
	}
	public String getBcontact() {
		return bcontact;
	}
	public void setBcontact(String bcontact) {
		this.bcontact = bcontact;
	}
	public String getBcity() {
		return bcity;
	}
	public void setBcity(String bcity) {
		this.bcity = bcity;
	}
	public String getBadress() {
		return badress;
	}
	public void setBadress(String badress) {
		this.badress = badress;
	}
	public String getBdor() {
		return bdor;
	}
	public void setBdor(String bdor) {
		this.bdor = bdor;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
