package com.kws.bloodbank.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kws.bloodbank.bean.FeedbackBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;


   public class FeedbackDAO  extends AbstractDataAccessObject
  {
	 Connection con=null;
	 PreparedStatement pst=null;
	 Statement st=null;
	 public FeedbackDAO()
	 {
		con=getConnection();
		System.out.println("Connection established");
	  }
	 public boolean postFeedback(FeedbackBean feedback )
	   {
		   boolean flag=false;
		  try {
			  int fid=getSequenceID("feedback","fid");
			  pst=con.prepareStatement("insert into feedback values(?,?,?,?,?)");
			   pst.setInt(1,fid);
			   pst.setString(2,feedback.getFirstname());
			   pst.setString(3,feedback.getLastname());
			   pst.setString(4,feedback.getMessage());
			   pst.setString(5,feedback.getMailid());
			   int cout=pst.executeUpdate();
			   if(cout!=0)
			   {
				   flag=true;
			   }
		} catch (Exception e) {
			flag=false;
			// TODO: handle exception
		}
		   return flag;
	   }
	 public  ArrayList<FeedbackBean> getFeedbacks()
	 {
		 ArrayList<FeedbackBean> feedbacks=new ArrayList<FeedbackBean>();
		 try {
			 st=con.createStatement();
			 ResultSet rs=st.executeQuery("select * from feedback");
			 
			 while(rs.next())
			 {
				 FeedbackBean feedback =new FeedbackBean();
				 feedback.setFid(rs.getInt(1));
				 feedback.setFirstname(rs.getString(2));
				 feedback.setLastname(rs.getString(3));
				 feedback.setMessage(rs.getString(4));
				 feedback.setMailid(rs.getString(5));
				 feedbacks.add(feedback);
			}
			 
		 } catch (Exception e) {
			e.printStackTrace();
		// TODO: handle exception
		}
		
		return feedbacks;
	 }
}
  
   