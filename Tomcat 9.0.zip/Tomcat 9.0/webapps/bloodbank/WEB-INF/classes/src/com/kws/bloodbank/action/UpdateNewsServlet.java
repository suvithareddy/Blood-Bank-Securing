package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.NewsBean;
import com.kws.bloodbank.dao.NewsDAO;

public class UpdateNewsServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String newsheader=request.getParameter("newsheader");
		String newsdescription =request.getParameter("newsdecription");
		String path1=request.getParameter("path1");
		String path2=request.getParameter("path2");
		NewsBean news=new NewsBean();
		news.setDescription(newsdescription);
		news.setHeader(newsheader);
		news.setImage(path1);
		news.setDoc(path2);
		
		boolean flag=false;
		NewsDAO newsDAO=new NewsDAO();
		flag=newsDAO.postNews(news);
		if(flag)
			response.sendRedirect("AdminHome.jsp?status=News sucessfully posted");
		else
			response.sendRedirect("AdminHome.jsp?status=Postin News Failure");
		
		

	}

}
