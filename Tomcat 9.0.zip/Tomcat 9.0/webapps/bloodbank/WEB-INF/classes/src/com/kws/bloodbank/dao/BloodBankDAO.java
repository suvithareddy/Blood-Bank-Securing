package com.kws.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.core.util.DateWrapper;


public class BloodBankDAO extends AbstractDataAccessObject {
	
	Connection con=null;
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	PreparedStatement pst2=null;
	Statement st=null;
	Statement st1=null;
	Statement st2=null;
	public BloodBankDAO()
	{

		con=getConnection();
		System.out.println("Connection established");
	}
	
	
  public boolean registerBloodBank(BloodBankBean bloodbank)
	   {
		   boolean flag=false;
		   int bid=0;
		    String bname=bloodbank.getBname();
		    String blocation=bloodbank.getBlocation();
		    String bcontact=bloodbank.getBcontact();
		    String bcity=bloodbank.getBcity();
		    String badress=bloodbank.getBadress();
		    int inchargeid=bloodbank.getInchargeId();
		    System.out.println("values sucessufully got to register bloodbank");
		    try
		    {
		    	con.setAutoCommit(false);
		    	bid=getSequenceID("bloodbanks", "bid");
		    	System.out.println(bid);
		    	pst=con.prepareStatement("insert into bloodbanks values(?,?,?,?,?,?,?,sysdate,?)");
		    	pst.setInt(1,bid);
		    	pst.setString(2,bname);
		    	pst.setString(3,blocation);
		    	pst.setString(4,bcity);
		    	pst.setString(5,bcontact);
		    	pst.setInt(6,inchargeid);
		    	pst.setString(7,badress);
		    	pst.setString(8,bloodbank.getState());
		    	int count=pst.executeUpdate();
		    	
		    	if(count!=0)
		    	{
		    		pst1=con.prepareStatement("update usermaster set alloted=? where userid=?");
					  pst1.setString(1,"yes");
					  pst1.setInt(2,inchargeid);
					  int count1=pst1.executeUpdate();
					    if(count1!=0)
					    {
					    	flag=true;
					    	con.commit();
					    }
					    else
					    	con.rollback();
		    	
		    	}
		    }catch (Exception e) {
		    	flag=false;
		    	try {
			    	con.rollback();	
				} catch (Exception e1) {
					e1.printStackTrace();
					// TODO: handle exception
				}
		    	e.printStackTrace();
				// TODO: handle exception
			}
		   return flag;
		   
		   
	   }
  
  public ArrayList<BloodBankBean> getBloodBanks()
  {
	   ArrayList<BloodBankBean> bloodbankList=new ArrayList<BloodBankBean>();
	   try
	   {
		   
           st=con.createStatement();
	     ResultSet rs=st.executeQuery("select * from bloodbanks");
		   while(rs.next())
		   {
			   BloodBankBean bloodBankBean=new BloodBankBean();
			   bloodBankBean.setBid(rs.getInt(1));
			   bloodBankBean.setBname(rs.getString(2));
			   bloodBankBean.setBlocation(rs.getString(3));
			   bloodBankBean.setBcity(rs.getString(4));
			   bloodBankBean.setBcontact(rs.getString(5));
			   bloodBankBean.setInchargeId(rs.getInt(6));
			   bloodBankBean.setBadress(rs.getString(7));
			   bloodBankBean.setBdor(DateWrapper.parseDate(rs.getDate(8)));
			   bloodBankBean.setState(rs.getString(9));
			  
			   bloodbankList.add(bloodBankBean);
		   }
	   }catch (Exception e) {
		   
		   e.printStackTrace();
		// TODO: handle exception
	}
	   return bloodbankList;
	   
  }
  
  
  
  public ArrayList<BloodBankBean> getBloodBank(String username, String password)
	{
	  System.out.println(username);
	  System.out.println(password);
	ArrayList<BloodBankBean> bList=new ArrayList<BloodBankBean>();
       try
	   {
	    	int inchargeid=0; 
				  pst1=con.prepareStatement(" select userid from usermaster  where username=? and password=?");
	    		  pst1.setString(1,username);
	    		  pst1.setString(2,password);
	              ResultSet rs1=pst1.executeQuery();
	              while(rs1.next())
	              {
	            	  inchargeid = rs1.getInt(1);
	              }
	              System.out.println(inchargeid);
	              pst=con.prepareStatement("select * from bloodbanks where binchargeid=?");
	              pst.setInt(1,inchargeid);
	              ResultSet rs=pst.executeQuery();
	       while(rs.next())
	      {
	    			  BloodBankBean bloodBankBean=new BloodBankBean();
	    			  bloodBankBean.setBid(rs.getInt(1));
	    			  bloodBankBean.setBname(rs.getString(2));
	    			  bloodBankBean.setBlocation(rs.getString(3));
	    			  bloodBankBean.setBcity(rs.getString(4));
	    			  bloodBankBean.setBcontact(rs.getString(5));
	    			  bloodBankBean.setInchargeId(rs.getInt(6));
	    			  bloodBankBean.setBadress(rs.getString(7));
	    			  bloodBankBean.setBdor(DateWrapper.parseDate(rs.getDate(8)));
	    			  bloodBankBean.setState(rs.getString(9));
	    	          bList.add(bloodBankBean);  
	    		  }
	    		  
	    	   }catch (Exception e) {
	    		   e.printStackTrace();
				// TODO: handle exception
			}
	    	  
		 
		 return bList;
	}
  
  
  public boolean  donationRequest(BloodBankBean blood)
  {
	  boolean flag=false;
	  int bid=blood.getBid();
 	 int did=blood.getDid();
 	 int inchargeid=blood.getInchargeId();
 	 String dname=blood.getDname();
 	 try
 	 {
 	  st=con.createStatement();
      int drid=getSequenceID("bloodbank_donation_request","drid");
     st1=con.createStatement();
	ResultSet rs=st1.executeQuery("select binchargeid from bloodbanks where bid="+bid);
		while(rs.next())
		{
			inchargeid=rs.getInt(1);
			
		}
      
        PreparedStatement pst=con.prepareStatement("insert into bloodbank_donation_request values(?,?,?,?,?,?)");
 		pst.setInt(1,drid);
 		pst.setInt(2,inchargeid);
 		pst.setInt(3,bid);
 		pst.setInt(4, did);
 		pst.setString(5,dname);
 		pst.setString(6,"pending");
 		int count=pst.executeUpdate();
 		if(count!=0)
 		{
 			flag=true;
 		}
 		else
 			flag=false;
 		}catch (Exception e) {
 		 flag=false;
 		 e.printStackTrace();
			// TODO: handle exception
		}
	  return flag;
	  
  } 
  public ArrayList<BloodBankBean> getDonationRequests()
  {
	  ArrayList<BloodBankBean> bloodbanks=new ArrayList<BloodBankBean>();
	  try {
		     
		    st=con.createStatement();
		    ResultSet rs=st.executeQuery("select b.drid,b.inchargeid,b.bid,b.donorid,b.donorname,b.status, u.bloodgroup from bloodbank_donation_request b,userdetails u where b.donorid=u.userid");
		    while (rs.next()) {
			BloodBankBean bloodbank=new BloodBankBean();
			bloodbank.setDrid(rs.getInt(1));
			bloodbank.setInchargeId(rs.getInt(2));
			bloodbank.setBid(rs.getInt(3));
			bloodbank.setDid(rs.getInt(4));
			bloodbank.setDname(rs.getString(5));
			bloodbank.setStatus(rs.getString(6));
			bloodbank.setBloodGroup(rs.getString(7));
			bloodbanks.add(bloodbank);
		  }
		
	} catch (Exception e) {
	  e.printStackTrace();	// TODO: handle exception
	}
	  return bloodbanks;
  }
  
  
  public boolean donationDetails(BloodBankBean bloodbank) {
		boolean flag = false;
		int did = getSequenceID("bloodbank_donation_details", "did");
		
		int bid=bloodbank.getBid();
		String dname=bloodbank.getDname();
		String bloodgroup=bloodbank.getBloodGroup();
		String samplename=bloodbank.getSampleName();
		int inchargeid=bloodbank.getInchargeId();
		String status=bloodbank.getStatus();
		
		
		
		try {
			con.setAutoCommit(false);
			pst = con.prepareStatement("insert into bloodbank_donation_details values(?,?,sysdate,sysdate+30,?,?,?,?,?,?)");
			pst.setInt(1,bloodbank.getBid());
			pst.setInt(2, did);
			pst.setString(3, bloodbank.getDname());
			pst.setString(4,bloodbank.getBloodGroup());
			pst.setString(5,bloodbank.getSampleName());
			pst.setInt(6,bloodbank.getInchargeId() );
			pst.setString(7,bloodbank.getStatus() );
			if(bloodbank.getStatus().equals("yes"))
			  pst.setString(8,bloodbank.getStatus() );
			else
				pst.setString(8,"no");
			int count = pst.executeUpdate();
			if (count != 0) {
				st=con.createStatement();
				int count1=st.executeUpdate("update bloodbank_donation_request set status='completed' where drid="+bloodbank.getDrid());
              if(count1!=0)
              {
              	flag=true;
              	con.commit();
              }
              else
              	con.rollback();
              	
			} else
				flag = false;

		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
			try {
				con.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
				// TODO: handle exception
			}
		}

		return flag;
	}
  public boolean  postBloodRequest(BloodBankBean bloodbank)
  {
	  boolean flag=false;
	  int bid=bloodbank.getBid();
	  int count=0;
	  int inchargeid=0;
	  try {
		 int brid=getSequenceID("bloodbank_blood_requests", "brid");
		  st=con.createStatement();
		  ResultSet rs=st.executeQuery("select binchargeid from bloodbanks where bid="+bid);
		 
		  while(rs.next())
		  {
			   inchargeid=rs.getInt(1);
	                 count++;
		  }
		  if(count>0)
		  {
			  pst=con.prepareStatement("insert into bloodbank_blood_requests values(?,?,?,?,?,?,?)");
			  pst.setInt(1,brid);
			  pst.setInt(2,bid);
			  pst.setInt(3,inchargeid);
			  pst.setInt(4,bloodbank.getRid());
			  pst.setString(5,bloodbank.getRname());
			  pst.setString(6,bloodbank.getBloodGroup());
			  pst.setString(7,"pending");
			  int count1=pst.executeUpdate();
			  if(count1!=0)
			  {
				  flag=true;
			  }
		  }
		
	} catch (Exception e) {
		flag=false;
		e.printStackTrace();
		// TODO: handle exception
	}
	  
	  return flag;
	  
  }
  
  
  
  public ArrayList<BloodBankBean> getBloodRequests()
  {
	  
	ArrayList<BloodBankBean>  bloodbanks=new ArrayList<BloodBankBean>();
	boolean flag=false;
	try {
		 st=con.createStatement();
		 ResultSet rs=st.executeQuery("select * from bloodbank_blood_requests");
		 while(rs.next())
		 {
			 BloodBankBean bloodbank=new BloodBankBean();	
			 bloodbank.setBrid(rs.getInt(1));
			 bloodbank.setBid(rs.getInt(2));
			 bloodbank.setInchargeId(rs.getInt(3));
			 bloodbank.setRecipientid(rs.getInt(4));
			 bloodbank.setRecipientname(rs.getString(5));
			 bloodbank.setBloodGroup(rs.getString(6));
			 bloodbank.setStatus(rs.getString(7));
			 bloodbanks.add(bloodbank);
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	
	
	return bloodbanks;
	  
  }
  
  
  public boolean sansionBlood(BloodBankBean bloodbank)
  {
	  int bid=bloodbank.getBid();
	  int inchargeid=bloodbank.getInchargeId();
	  int recipientid=bloodbank.getRecipientid();
	  String bloodgroup=bloodbank.getBloodGroup();
	  String recipientname=bloodbank.getRecipientname();
	  int brid=bloodbank.getBrid();
	  if(bloodgroup.equalsIgnoreCase("AB"))
			 bloodgroup="AB+ve";
		 if(bloodgroup.equalsIgnoreCase("AB"))
			 bloodgroup="AB+ve";
			 
		 if(bloodgroup.equalsIgnoreCase("A"))
			 bloodgroup="A+ve";
		 if(bloodgroup.equalsIgnoreCase("B"))
			 bloodgroup="B+ve";
		 if(bloodgroup.equalsIgnoreCase("O"))
			 bloodgroup="O+ve";
		 if(bloodgroup.equals("A1"))
			 bloodgroup="A1+ve";
		 if(bloodgroup.equals("A2"))
			 bloodgroup="A2+ve";
		 if(bloodgroup.equals("A1B"))
			 bloodgroup="A1B+ve";
		 if(bloodgroup.equals("A2B"))
			 bloodgroup="A2B+ve";
	  boolean flag=false;
	  try 
	{
		    int count=0;
		    con.setAutoCommit(false);
		    pst=con.prepareStatement(" select * from bloodbank_donation_details where bloodgroup=? and binchargeid=? and available=?");
		    pst.setString(1, bloodgroup);
		    pst.setInt(2, inchargeid);
		    pst.setString(3,"yes");
		    ResultSet rs=pst.executeQuery();
		      while(rs.next())
		        {
		    	   count++;
		    	   bloodbank.setSampleName(rs.getString(7));
		    	   break;
		       }
		 if(count!=0)
		    {
		    	st=con.createStatement();
		    	int count1=st.executeUpdate("update  bloodbank_donation_details set AVAILABLE='no' where samplename='"+bloodbank.getSampleName()+"'");
		         if(count1!=0)
		         {
		        	      pst1=con.prepareStatement("insert into bloodbank_reception_details values(?,?,?,?,sysdate)");
		        	      pst1.setInt(1,bid);
		        	      pst1.setInt(2, recipientid);
		        	      pst1.setString(3,recipientname);
		        	      pst1.setString(4,bloodgroup);
		        	      int count2=pst1.executeUpdate();
		        	         if(count2!=0)
		        	          {
		        		                st2=con.createStatement();
		        		               int check=st2.executeUpdate("update bloodbank_blood_requests set status='alloted' where brid='"+brid+"'");
		        		                 if(check!=0)
		        		                 {
		        		                       con.commit();
		        		                      flag=true;
		        		                  }
		        	               }
		        		   
		         }
		         
		    }
		      else
		         {
		        	 pst2=con.prepareStatement("select samplename FROM camp_donation_registered where cincharge=? and bloodgroup=? and AVAILABILITY=?");
		        	 pst2.setInt(1,inchargeid);
		        	 pst2.setString(2,bloodgroup);
		        	 pst2.setString(3,"yes");
		        	 ResultSet rs2=pst2.executeQuery();
		        	 while(rs2.next())
		        	 {
		        		 count++;
		        		 bloodbank.setSampleName(rs2.getString(1));
		        		 break;
		        	 }
		        	         if(count!=0)
		        	         {
		        			    	st=con.createStatement();
		        			    	int count3=st.executeUpdate("update  camp_donation_registered set AVAILABILITY='no' where samplename='"+bloodbank.getSampleName()+"'");
		        			         if(count3!=0)
		        			         {
		        			        	 pst1=con.prepareStatement("insert into bloodbank_reception_details values(?,?,?,?,sysdate)");
		        			        	 pst1.setInt(1,bid);
		        			        	 pst1.setInt(2, recipientid);
		        			        	 pst1.setString(3,recipientname);
		        			        	 pst1.setString(4,bloodgroup);
		        			        	 int count4=pst1.executeUpdate();
		        			        	   if(count4!=0)
		        			        	   {
		        			        		   st2=con.createStatement();
		        			        		   int check=st2.executeUpdate("update bloodbank_blood_requests set status='alloted' where brid='"+brid+"'");
		        			        		   if(check!=0)
		        			        		   {
		        			        		     con.commit();
		        			        		     flag=true;
		        			        		   }
		        			        	   }
		        			        		   
		        			         }
		        	        	 
		        	            }
		        	 
		               }
		    
		    if(count==0)
		    {
		    	
		    	st=con.createStatement();
		    	int check=st.executeUpdate("Update bloodbank_blood_requests set status='not available' where brid='"+brid+"'");
                if(check!=0)
                {
                	flag=true;
                	con.commit();
                }
		    }
		    
	} 
	  catch (Exception e) {
		flag=false;
		e.printStackTrace();
		try {
		
			con.rollback();
			flag=false;
		} catch (Exception e1) {
			e1.printStackTrace();
			// TODO: handle exception
		}
		// TODO: handle exception
	}
	  return flag;
	  
  }
  
  
  
  public boolean rejectRequest(BloodBankBean bloodbank)
  {
	  boolean flag=false;
	  int brid=bloodbank.getBrid();
	  try {
		  st=con.createStatement();
	  	  int check=st.executeUpdate("update bloodbank_blood_requests set status='not available' where brid='"+brid+"'");
	  	  if(check!=0)
	  	  {
	  		  flag=true;
	  		  
	  	  }
		
	} catch (Exception e) {
		e.printStackTrace();
		flag=false;
		// TODO: handle exception
	}
	  
	  
      return flag;
      
      }
  
  
  
  public ArrayList<BloodBankBean> getDonations()
  {
	  ArrayList<BloodBankBean> blist=new ArrayList<BloodBankBean>();
	  try
	  {
		  st=con.createStatement();
		  ResultSet rs=st.executeQuery("select b.bname,bd.bloodgroup,bd.donationdate,bd.donorname from bloodbanks b,bloodbank_DONATION_DETAILS bd where b.bid=bd.bid");
		
		  while(rs.next())
		  {
			  BloodBankBean bloodbankBean=new BloodBankBean();
			  bloodbankBean.setBname(rs.getString(1));
			  bloodbankBean.setBloodGroup(rs.getString(2));
			  bloodbankBean.setDonationDate(DateWrapper.parseDate(rs.getDate(3)));
			  bloodbankBean.setDname(rs.getString(4));
			 blist.add(bloodbankBean);
			 
		  }
		  
	  }catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}
	  return blist;
  

  
  }
  
  
  public ArrayList<BloodBankBean> getTransfusions()
  {
	  ArrayList<BloodBankBean> Blist=new ArrayList<BloodBankBean>();
	   try {
		   st=con.createStatement();
		   ResultSet rs=st.executeQuery("select b.bname,br.recipientname,br.bloodgroup,br.dos from bloodbanks b ,bloodbank_RECEPTION_DETAILS br where b.bid=br.bid");
		   while(rs.next())
			{
			   BloodBankBean bloodBankBean=new BloodBankBean();
			   bloodBankBean.setBname(rs.getString(1));
			   bloodBankBean.setRecipientname(rs.getString(2));
			   bloodBankBean.setBloodGroup(rs.getString(3));
			   bloodBankBean.setDonationDate(DateWrapper.parseDate(rs.getDate(4)));
				Blist.add(bloodBankBean);
			}
			
	} catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	   return Blist;
  }
  public ArrayList<BloodBankBean> getDonorDonation(String donorname)
  {
	  ArrayList<BloodBankBean> blist=new ArrayList<BloodBankBean>();
		  try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select b.bname,bd.donorname,bd.donationdate from bloodbanks b, bloodbank_DONATION_DETAILS bd where b.bid=bd.bid and bd.donorname='"+donorname+"'");
		  
			 while(rs.next())
			 {
				 BloodBankBean bloodbank=new BloodBankBean();
				 bloodbank.setBname(rs.getString(1));
				 bloodbank.setDname(rs.getString(2));
				 bloodbank.setDonationDate(DateWrapper.parseDate(rs.getDate(3)));
				 blist.add(bloodbank);
			 }
		  } catch (Exception e) {
			// TODO: handle exception
		} 
		   
		   return blist;
			  
  }
  
  
  public ArrayList<BloodBankBean> getStatus(BloodBankBean bankBean)
  {
	   int recipientid=bankBean.getRecipientid();
	  ArrayList<BloodBankBean> blist=new ArrayList<BloodBankBean>();
		  try {
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery("select bloodgroup,status from BLOODBANK_BLOOD_REQUESTS where RECIPIENTID="+recipientid);
				 while(rs.next())
			 {
				 BloodBankBean bloodbank=new BloodBankBean();
				 bloodbank.setBloodGroup(rs.getString(1));
				 bloodbank.setStatus(rs.getString(2));

				 blist.add(bloodbank);
			 }
		  } catch (Exception e) {
			// TODO: handle exception
		} 
			   return blist;
	  }
  
  
  

}
