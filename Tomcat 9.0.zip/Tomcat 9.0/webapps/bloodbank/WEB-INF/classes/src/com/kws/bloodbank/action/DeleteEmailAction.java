package com.kws.bloodbank.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.dao.EmailDAO;
import javax.servlet.RequestDispatcher;

public class DeleteEmailAction extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String emails[]=request.getParameterValues("eid"); 
		EmailDAO emailDAO=new EmailDAO();
		int count=0; 
		 for(String email:emails) 
		 { 
		   int emailid=Integer.parseInt(email); 
		   boolean flag=emailDAO.deleteEmail(emailid);
		   if(flag)
		   {
		   count++;
		   }
		  }
		String  target ="ViewEmails.jsp?status="+count+" "+"emails deleted";
		                 RequestDispatcher rd = request.getRequestDispatcher(target);
		                 rd.forward(request,response);     
	}

}
