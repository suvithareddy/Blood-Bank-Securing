package com.kws.bloodbank.action;

import java.io.IOException;
import com.kws.bloodbank.dao.UserMasterDAO;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.HospitaDAO;
import com.kws.bloodbank.bean.HospitalBean;

public class RegisterHospitalServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
			{
		boolean flag=false;
		HospitalBean hospital=new HospitalBean();
		hospital.setHname(request.getParameter("hname"));
		hospital.setHlocation(request.getParameter("hlocation"));
		hospital.setHcity(request.getParameter("hcity"));
		hospital.setHcontact(request.getParameter("hcontact"));
		hospital.setHadress(request.getParameter("hadress"));
	     hospital.setInchargeId(Integer.parseInt(request.getParameter("volunteerid")));
	     String hstate=request.getParameter("hstate");
	     hospital.setState(request.getParameter("hstate"));
		System.out.println("values to the hospitalbean class is sucessfully set in RegisterHospitalServlet");
		 
		HospitaDAO hdao= new HospitaDAO();
		flag=hdao.registerHospital(hospital);
         if(flag)
       	  response.sendRedirect("AdminHome.jsp?status=Hospital Registration Success");
         else
       	  response.sendRedirect("AdminHome.jsp?status=Hospital Registration Failure");
		
	}

}
