package com.kws.bloodbank.bean;

public class HospitalBean {

	
	private int hid;
	private String hcontact;
    private String hadress;
    private String hcity;
    private String hdor;
	private String state;
	private String hname;
	private String hlocation;
	private int inchargeId;
    private int did;
    private String dname;
    private String donationDate;
    private String expiryDate;
    private String bloodGroup;
    private String sampleName;
    private int drid;
    private String status;
    private String rname;
    private int rid;
    private String available;
    private int brid;
    private int recipientid;
    private String recipientname;
    
	public String getRecipientname() {
		return recipientname;
	}
	public void setRecipientname(String recipientname) {
		this.recipientname = recipientname;
	}
	public int getRecipientid() {
		return recipientid;
	}
	public void setRecipientid(int recipientid) {
		this.recipientid = recipientid;
	}
	public int getBrid() {
		return brid;
	}
	public void setBrid(int brid) {
		this.brid = brid;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public int getHid() {
		return hid;
	}
	public void setHid(int hid) {
		this.hid = hid;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public String getHlocation() {
		return hlocation;
	}
	public void setHlocation(String hlocation) {
		this.hlocation = hlocation;
	}
	public int getInchargeId() {
		return inchargeId;
	}
	public void setInchargeId(int inchargeId) {
		this.inchargeId = inchargeId;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(String donationDate) {
		this.donationDate = donationDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getSampleName() {
		return sampleName;
	}
	public void setSampleName(String sampleName) {
		this.sampleName = sampleName;
	}
	public String getHcontact() {
		return hcontact;
	}
	public void setHcontact(String hcontact) {
		this.hcontact = hcontact;
	}
	public String getHadress() {
		return hadress;
	}
	public void setHadress(String hadress) {
		this.hadress = hadress;
	}
	public String getHcity() {
		return hcity;
	}
	public void setHcity(String hcity) {
		this.hcity = hcity;
	}
	public String getHdor() {
		return hdor;
	}
	public void setHdor(String hdor) {
		this.hdor = hdor;
	}
	public int getDrid() {
		return drid;
	}
	public void setDrid(int drid) {
		this.drid = drid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
    
}
