package com.kws.bloodbank.core.db;

import com.kws.bloodbank.core.dao.AbstractDataAccessObject;




public class DBFactory
{
	public DBFactory()
	{
		new AbstractDataAccessObject().getConnection();
	}
}
