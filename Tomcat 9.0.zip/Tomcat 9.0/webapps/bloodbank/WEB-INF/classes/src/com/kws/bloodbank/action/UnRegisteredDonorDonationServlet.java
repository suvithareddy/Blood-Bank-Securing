package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.UnregisteredDonorBean;
import com.kws.bloodbank.dao.UnRegisteredDonorDAO;

public class UnRegisteredDonorDonationServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
    int cid=Integer.parseInt(request.getParameter("campid"));
	int inchargeid=Integer.parseInt(request.getParameter("vid"));
	String cname=request.getParameter("campname");
	UnregisteredDonorBean donor=new UnregisteredDonorBean();
	donor.setAdress(request.getParameter("adress"));
	donor.setBloodgroup(request.getParameter("bloodgroup"));
	  donor.setCampdonor(request.getParameter("donorname"));
	  donor.setCampid(cid);
	  donor.setCity(request.getParameter("city"));
	  donor.setContact(request.getParameter("contact"));
	  donor.setInchargeid(inchargeid);
	  donor.setSamplename(request.getParameter("samplename"));
	  donor.setSamplestatus(request.getParameter("accepted"));
	  boolean flag=false;
	   UnRegisteredDonorDAO unregistered=new UnRegisteredDonorDAO();
	   flag=unregistered.donationDetails(donor);
	  String target=null;
	  if(flag)
		  target="UploadCampDonationDetails.jsp?campid="+cid+"&vid="+inchargeid+"&campname="+cname+"&status=upload sucessful";
	  else
		  target="UploadCampDonationDetails.jsp?campid="+cid+"&vid="+inchargeid +"&campname="+cname+"&status=upload failure";
	  RequestDispatcher rd=request.getRequestDispatcher(target);
	  rd.forward(request, response);
	  }

}
