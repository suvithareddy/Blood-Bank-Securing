package com.kws.bloodbank.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.HospitaDAO;

public class HospitalDonationRequestServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		HttpSession session = request.getSession();
		int hid = Integer.parseInt(request.getParameter("hospitalid"));
		int donorid = (Integer) (session.getAttribute("userid"));
		System.out.println(donorid);
		String dname = (String) (session.getAttribute("user"));
		String target = "DonorHome.jsp?status=Donation Request Rejected";
		HospitalBean hospital = new HospitalBean();
		hospital.setHid(hid);
		hospital.setDid(donorid);
		hospital.setDname(dname);
	    HospitaDAO hospitaDAO = new HospitaDAO();
		boolean flag = hospitaDAO.donationRequest(hospital);
		if (flag) {
			response.sendRedirect("DonorHome.jsp?status=Donation Request Accepted");

		} else {
			response.sendRedirect("DonorHome.jsp?status=Donation Request Rejected");
		}
		
	}

}
