package com.kws.bloodbank.action;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.BloodBankDAO;
import com.kws.bloodbank.dao.HospitaDAO;
public class BloodBankDonationServlet extends HttpServlet {
public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
public void doPost(HttpServletRequest request, HttpServletResponse response)
 	throws ServletException, IOException {
	String status = request.getParameter("accepted");
	String samplename = request.getParameter("samplename");
	String bloodgroup = request.getParameter("bloodgroup");
	HttpSession session = request.getSession();
	int inchargeid = (Integer) (session.getAttribute("userid"));
	int bid = Integer.parseInt(request.getParameter("bid"));
	System.out.println(bid);
	System.out.println(bid);
	int drid = Integer.parseInt(request.getParameter("drid"));
	String dname=request.getParameter("donorname");
	BloodBankBean bloodbank = new BloodBankBean();
	bloodbank.setStatus(status);
	bloodbank.setDrid(drid);
	bloodbank.setDname(dname);
	bloodbank.setBid(bid);
	bloodbank.setDname(dname);
	bloodbank.setInchargeId(inchargeid);
	bloodbank.setSampleName(samplename);
	bloodbank.setBloodGroup(bloodgroup);
	bloodbank.setStatus(request.getParameter("accepted"));
	boolean flag = false;
	BloodBankDAO bloodbankDAO =new BloodBankDAO();
	flag = bloodbankDAO.donationDetails(bloodbank);
    String target = null;
	if (flag)
	response.sendRedirect("VolunteerHome.jsp?status=upload sucessful");
	else
	response.sendRedirect("VolunteerHome.jsp?status=upload failure");
	//RequestDispatcher rd = request.getRequestDispatcher(target);
	//rd.forward(request, response);
   }

}
