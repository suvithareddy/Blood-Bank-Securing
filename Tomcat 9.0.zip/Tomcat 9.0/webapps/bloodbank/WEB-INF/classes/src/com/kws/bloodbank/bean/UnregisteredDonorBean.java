package com.kws.bloodbank.bean;

public class UnregisteredDonorBean {

	private int sampleid;
	private String samplename;
	private int campid;
	private int inchargeid;
	private String campdonor;
	private String bloodgroup;
	private String contact;
	private String city;
	private String adress;
	private String samplestatus;
	public int getSampleid() {
		return sampleid;
	}
	public void setSampleid(int sampleid) {
		this.sampleid = sampleid;
	}
	public String getSamplename() {
		return samplename;
	}
	public void setSamplename(String samplename) {
		this.samplename = samplename;
	}
	public int getCampid() {
		return campid;
	}
	public void setCampid(int campid) {
		this.campid = campid;
	}
	public int getInchargeid() {
		return inchargeid;
	}
	public void setInchargeid(int inchargeid) {
		this.inchargeid = inchargeid;
	}
	public String getCampdonor() {
		return campdonor;
	}
	public void setCampdonor(String campdonor) {
		this.campdonor = campdonor;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getSamplestatus() {
		return samplestatus;
	}
	public void setSamplestatus(String samplestatus) {
		this.samplestatus = samplestatus;
	}
	
	
}
