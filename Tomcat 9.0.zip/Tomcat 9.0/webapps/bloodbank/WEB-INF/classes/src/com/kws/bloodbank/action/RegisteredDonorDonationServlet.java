package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.Request;

import com.kws.bloodbank.bean.RegisteredDonorBean;
import com.kws.bloodbank.bean.UserMasterBean;
import com.kws.bloodbank.dao.RegisteredDonorDAO;
import com.kws.bloodbank.dao.UserMasterDAO;
import com.sun.corba.se.spi.protocol.RequestDispatcherDefault;

public class RegisteredDonorDonationServlet extends HttpServlet
  {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException 
	{
     int cid=Integer.parseInt(request.getParameter("campid"));
     int inchargeid=Integer.parseInt(request.getParameter("vid"));
     String cname=request.getParameter("campname");
     int donorid=Integer.parseInt(request.getParameter("donorusername"));
    //UserMasterBean user=new UserMasterDAO().getDonor(donorusername);
    
     System.out.println(donorid);
     String samplename=request.getParameter("samplename");
     String bloodgroup=request.getParameter("bloodgroup");
     String accepted=request.getParameter("accepted");
     RegisteredDonorBean registered=new RegisteredDonorBean();
     registered.setBloodgroup(bloodgroup);
     registered.setCampdonorid(donorid);
     registered.setCampid(cid);
     registered.setInchargeid(inchargeid);
     registered.setSamplename(samplename);
     registered.setSamplestatus(accepted);
     boolean flag=new RegisteredDonorDAO().donationDetails(registered);
     String target=null;
     if(flag)
     {
    	target="UploadCampDonationDetails.jsp?campid="+cid+"&vid="+inchargeid+"&campname="+cname+"&status=upload sucessful";
     }
     else
     {
    	target="UploadCampDonationDetails.jsp?campid="+cid+"&vid="+inchargeid+"&campname="+cname+"&status=upload failure";    	
     }
      RequestDispatcher dispatcher=request.getRequestDispatcher(target);
      dispatcher.forward(request, response);
      }
    }
