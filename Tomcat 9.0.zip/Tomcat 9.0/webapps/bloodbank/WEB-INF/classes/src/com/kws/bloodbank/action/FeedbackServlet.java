package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.FeedbackBean;
import com.kws.bloodbank.dao.FeedbackDAO;

public class FeedbackServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	        FeedbackBean feedback=new FeedbackBean();
	        feedback.setFirstname(request.getParameter("firstname"));
	        feedback.setLastname(request.getParameter("lastname"));
	        feedback.setMailid(request.getParameter("emailid"));
	        feedback.setMessage(request.getParameter("message"));
	        boolean flag=new FeedbackDAO().postFeedback(feedback);
	        String target=null;
	        if(flag)
	        	target="Feedback.jsp?fstatus=feedback posted sucessfully Thank you";
	        else 
				
	        	target="Feedback.jsp?fstatus=feedback posting failed";	
	        request.getRequestDispatcher(target).forward(request, response);
	}

}
