package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.UserMasterBean;
import com.kws.bloodbank.dao.UserMasterDAO;

public class ForgotPassworServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username=request.getParameter("username");
		String securityQuestion=request.getParameter("secutityquestion");
		String securityAnswer=request.getParameter("securityanswer");
		boolean flag=false;
		UserMasterDAO userMasterDAO=new UserMasterDAO();
		UserMasterBean userMasterBean=new UserMasterBean();
		userMasterBean.setUsername(username);
		userMasterBean.setSecurityques(securityQuestion);
		userMasterBean.setSecurityans(securityAnswer);
		
		String password=userMasterDAO.forgotPassword(userMasterBean);
		if(password!=null)
			response.sendRedirect("MyPassword.jsp?status= Your Password is:"+password);
		else
			response.sendRedirect("MyPassword.jsp?status=you are not a valid user");
	}

}
