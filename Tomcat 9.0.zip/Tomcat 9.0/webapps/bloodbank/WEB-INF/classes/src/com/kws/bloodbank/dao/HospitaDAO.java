package com.kws.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.core.util.DateWrapper;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

public class HospitaDAO extends AbstractDataAccessObject {
    Connection con = null;
	PreparedStatement pst = null;
	PreparedStatement pst1 = null;
	PreparedStatement pst2=null;
	PreparedStatement pst3=null;
	PreparedStatement pst4=null;
	PreparedStatement pst5=null;
	Statement st = null;
	Statement st1=null;
	Statement st2=null;

	public HospitaDAO() {
		con = getConnection();
		System.out.println("Connection established");
	}

	public boolean registerHospital(HospitalBean hospital) {
		boolean flag = false;
		
		int hid = 0;
		String hname = hospital.getHname();
		String hlocation = hospital.getHlocation();
		String hcontact = hospital.getHcontact();
		String hcity = hospital.getHcity();
		String hadress = hospital.getHadress();
		String hstate=hospital.getState();
		System.out.println("hospital State"+hstate);
		int inchargeid = hospital.getInchargeId();
		System.out.println("values sucessufully got to register hopital");
		try {
			con.setAutoCommit(false);
			hid = getSequenceID("hospitals", "hid");
		PreparedStatement	pst = con
					.prepareStatement("insert into hospitals values(?,?,?,?,?,?,?,sysdate,?)");
			pst.setInt(1, hid);
			pst.setString(2, hname);
			pst.setString(3, hlocation);
			pst.setString(4, hcity);
			pst.setString(5, hcontact);
			pst.setInt(6, inchargeid);
			pst.setString(7, hadress);
			pst.setString(8,hstate);
			int count = pst.executeUpdate();
            if (count != 0) {
			  pst1=con.prepareStatement("update usermaster set alloted=? where userid=?");
			  pst1.setString(1,"yes");
			  pst1.setInt(2,inchargeid);
			  int count1=pst1.executeUpdate();
			    if(count1!=0)
			    {
			    	flag=true;
			    	con.commit();
			    }
			    else
			    	con.rollback();
			}
		} catch (Exception e) {
			
		    flag = false;
		    try {
		    	con.rollback();	
			} catch (Exception e1) {
				e1.printStackTrace();
				// TODO: handle exception
			}
			e.printStackTrace();
		}
		return flag;
	}

	public ArrayList<HospitalBean> getHospitals() {
		ArrayList<HospitalBean> hospitalList = new ArrayList<HospitalBean>();
		try {

			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from hospitals");
			while (rs.next()) {
			HospitalBean hospitalBean = new HospitalBean();
			hospitalBean.setHid(rs.getInt(1));
			hospitalBean.setHname(rs.getString(2));
			hospitalBean.setHlocation(rs.getString(3));
			hospitalBean.setHcity(rs.getString(4));
			hospitalBean.setHcontact(rs.getString(5));
			hospitalBean.setInchargeId(rs.getInt(6));
			hospitalBean.setHadress(rs.getString(7));
			hospitalBean.setHdor(DateWrapper.parseDate(rs.getDate(8)));
			hospitalBean.setState(rs.getString(8));
			hospitalList.add(hospitalBean);
			}
		} catch (Exception e) {

			e.printStackTrace();
			// TODO: handle exception
		}
		return hospitalList;
	}

	public ArrayList<HospitalBean> getHospital(String username, String password) {
	
		ArrayList<HospitalBean> hospitalList = new ArrayList<HospitalBean>();
		try {
			  int userid=0;
			  pst1 = con.prepareStatement(" select userid from usermaster where username=? and password=?");
			  pst1.setString(1, username);
			  pst1.setString(2,password);
			  ResultSet rs = pst1.executeQuery();
			  while(rs.next())
			{
			  userid=rs.getInt(1);
			}
			pst=con.prepareStatement("select * from hospitals where hinchargeid=?");
			pst.setInt(1,userid);
			ResultSet rs1=pst.executeQuery();
		   while (rs1.next()) {
				HospitalBean hospitalBean = new HospitalBean();
				hospitalBean.setHid(rs1.getInt(1));
				hospitalBean.setHname(rs1.getString(2));
				hospitalBean.setHlocation(rs1.getString(3));
				hospitalBean.setHcity(rs1.getString(4));
				hospitalBean.setHcontact(rs1.getString(5));
				hospitalBean.setInchargeId(rs1.getInt(6));
				hospitalBean.setHadress(rs1.getString(7));
				hospitalBean.setHdor(DateWrapper.parseDate(rs1.getDate(8)));
				hospitalBean.setState(rs1.getString(9));
			    hospitalList.add(hospitalBean);
			}

		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

		return hospitalList;
	}

	public boolean donationRequest(HospitalBean hospital) {
		boolean flag = false;
		int hid = hospital.getHid();
		int did = hospital.getDid();
		int inchargeid = 0;
		System.out.println(hid);
		System.out.println(did);
		System.out.println(inchargeid);
		System.out.println(hid);

		String dname = hospital.getDname();
		try {
			
			
			int drid = getSequenceID("hospital_donation_request", " drid");
			st1=con.createStatement();
			ResultSet rs=st1.executeQuery("select hinchargeid from hospitals where hid="+hid);
			while(rs.next())
			{
				inchargeid=rs.getInt(1);
				
			}
			PreparedStatement pst = con.prepareStatement("insert into hospital_donation_request values(?,?,?,?,?,?)");
			pst.setInt(1, drid);
			pst.setInt(2, inchargeid);
			pst.setInt(3, hid);
			pst.setInt(4, did);
			pst.setString(5, dname);
			pst.setString(6, "pending");
			int count = pst.executeUpdate();
			if (count != 0) {
				flag = true;
			} else
				flag = flag;
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
			// TODO: handle exception
		}
		return flag;

	}

public ArrayList<HospitalBean> getDonationRequests() {
		ArrayList<HospitalBean> hospitals = new ArrayList<HospitalBean>();
		try {
			
			st = con.createStatement();
			ResultSet rs = st
					.executeQuery("select h.drid,h.inchargeid,h.hid,h.donorid,h.donorname,h.status,u.bloodgroup from  hospital_donation_request h,userdetails u where h.donorid=u.userid");
			while (rs.next()) {
				HospitalBean hospital = new HospitalBean();
				hospital.setDrid(rs.getInt(1));
				hospital.setInchargeId(rs.getInt(2));
				hospital.setHid(rs.getInt(3));
				hospital.setDid(rs.getInt(4));
				hospital.setDname(rs.getString(5));
				hospital.setStatus(rs.getString(6));
				hospital.setBloodGroup(rs.getString(7));
				hospitals.add(hospital);
			}

		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

		return hospitals;
	} 
	public boolean donationDetails(HospitalBean hospital) {
		boolean flag = false;
		int did = getSequenceID("hospital_donation_details", "did");

		try {
			con.setAutoCommit(false);
			pst = con.prepareStatement("insert into hospital_donation_details values(?,?,sysdate,sysdate+30,?,?,?,?,?,?)");
			pst.setInt(1,hospital.getHid());
			pst.setInt(2, did);
			pst.setString(3, hospital.getDname());
			pst.setString(4,hospital.getBloodGroup());
			pst.setString(5,hospital.getSampleName());
			pst.setInt(6,hospital.getInchargeId() );
			pst.setString(7,hospital.getStatus() );
			if(hospital.getStatus().equals("yes"))
			  pst.setString(8,hospital.getStatus() );
			else
				pst.setString(8,"no");
			int count = pst.executeUpdate();
			if (count != 0) {
				st=con.createStatement();
				int count1=st.executeUpdate("update hospital_donation_request set status='completed' where drid="+hospital.getDrid());
                if(count1!=0)
                {
                	flag=true;
                	con.commit();
                }
                else
                	con.rollback();
                	
			} else
				flag = false;

		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
			try {
				con.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
				// TODO: handle exception
			}
		}

		return flag;
	}
  public ArrayList<HospitalBean> getDonations()
  {
	  ArrayList<HospitalBean> hlist=new ArrayList<HospitalBean>();
	  try
	  {
		  st=con.createStatement();
		  ResultSet rs=st.executeQuery("select h.hname,hd.bloodgroup,hd.donationdate,hd.donorname from hospitals h,HOSPITAL_DONATION_DETAILS hd where h.hid=hd.hid");
		  String hname=null;
		  while(rs.next())
		  {
			 HospitalBean hospitalBean=new HospitalBean();
			 hospitalBean.setHname(rs.getString(1));
			 hospitalBean.setBloodGroup(rs.getString(2));
			 hospitalBean.setDonationDate(DateWrapper.parseDate(rs.getDate(3)));
			 hospitalBean.setDname(rs.getString(4));
			 hlist.add(hospitalBean);
			 
		  }
		  
	  }catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}
	  return hlist;
	  
  }
  public boolean postBloodRequest(HospitalBean hospital)
  {
	  boolean flag=false;
	  int hid=hospital.getHid();
	  int count=0;
	  int inchargeid=0;
	  try {
		 int brid=getSequenceID("hospital_blood_requests", "brid");
		  st=con.createStatement();
		  ResultSet rs=st.executeQuery("select hinchargeid from hospitals where hid="+hid);
		 
		  while(rs.next())
		  {
			   inchargeid=rs.getInt(1);
	                 count++;
		  }
		  if(count>0)
		  {
			  pst=con.prepareStatement("insert into hospital_blood_requests values(?,?,?,?,?,?,?)");
			  pst.setInt(1,brid);
			  pst.setInt(2,hid);
			  pst.setInt(3,inchargeid);
			  pst.setInt(4,hospital.getRid());
			  pst.setString(5,hospital.getRname());
			  pst.setString(6,hospital.getBloodGroup());
			  pst.setString(7,"pending");
			  int count1=pst.executeUpdate();
			  if(count1!=0)
			  {
				  flag=true;
			  }
		  }
		
	} catch (Exception e) {
		flag=false;
		e.printStackTrace();
		// TODO: handle exception 
	}
	  
	  return flag;
  }
  public ArrayList<HospitalBean> getBloodRequests()
  {
	  
	ArrayList<HospitalBean>  hospitals=new ArrayList<HospitalBean>();
	boolean flag=false;
	try {
		 st=con.createStatement();
		 ResultSet rs=st.executeQuery("select * from hospital_blood_requests");
		 while(rs.next())
		 {
			 HospitalBean hospital=new HospitalBean();
			 hospital.setBrid(rs.getInt(1));
			 hospital.setHid(rs.getInt(2));
			 hospital.setInchargeId(rs.getInt(3));
			 hospital.setRecipientid(rs.getInt(4));
			 hospital.setRecipientname(rs.getString(5));
			 hospital.setBloodGroup(rs.getString(6));
			 hospital.setStatus(rs.getString(7));
			 hospitals.add(hospital);
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	
	
	return hospitals;
	  
  }
  public boolean sansionBlood(HospitalBean hospital)
  {
	  int hid=hospital.getHid();
	  int inchargeid=hospital.getInchargeId();
	  int recipientid=hospital.getRecipientid();
	  String bloodgroup=hospital.getBloodGroup();
	  String recipientname=hospital.getRecipientname();
	  int brid=hospital.getBrid();
	  
	  if(bloodgroup.equalsIgnoreCase("AB"))
			 bloodgroup="AB+ve";
		 if(bloodgroup.equalsIgnoreCase("AB"))
			 bloodgroup="AB+ve";
			 
		 if(bloodgroup.equalsIgnoreCase("A"))
			 bloodgroup="A+ve";
		 if(bloodgroup.equalsIgnoreCase("B"))
			 bloodgroup="B+ve";
		 if(bloodgroup.equalsIgnoreCase("O"))
			 bloodgroup="O+ve";
		 if(bloodgroup.equals("A1"))
			 bloodgroup="A1+ve";
		 if(bloodgroup.equals("A2"))
			 bloodgroup="A2+ve";
		 if(bloodgroup.equals("A1B"))
			 bloodgroup="A1B+ve";
		 if(bloodgroup.equals("A2B"))
			 bloodgroup="A2B+ve";
	  boolean flag=false;
	  try 
	{
		    int count=0;
		    con.setAutoCommit(false);
		    pst=con.prepareStatement(" select * from hospital_donation_details where bloodgroup=? and hinchargeid=? and available=?");
		    pst.setString(1, bloodgroup);
		    pst.setInt(2, inchargeid);
		    pst.setString(3,"yes");
		    ResultSet rs=pst.executeQuery();
		 while(rs.next())
		   {
		    	   count++;
		    	   hospital.setSampleName(rs.getString(7));
		    	   System.out.println(rs.getString(7));
		    	   break;
		       }
		 if(count!=0)
		    {
		    	pst4=con.prepareStatement("update hospital_donation_details set available=? where samplename=?");
		    	pst4.setString(1,"no");
		    	pst4.setString(2,hospital.getSampleName());
		        int count1=pst.executeUpdate(); 
		    	if(count1!=0)
		         {
		        	      pst1=con.prepareStatement("insert into hospital_reception_details values(?,?,?,?,sysdate)");
		        	      pst1.setInt(1,hid);
		        	      pst1.setInt(2, recipientid);
		        	      pst1.setString(3,recipientname);
		        	      pst1.setString(4,bloodgroup);
		        	      int count2=pst1.executeUpdate();
		        	         if(count2!=0)
		        	          {
		        		                st2=con.createStatement();
		        		               int check=st2.executeUpdate("update hospital_blood_requests set status='alloted' where brid='"+brid+"'");
		        		                 if(check!=0)
		        		                 {
		        		                       con.commit();
		        		                      flag=true;
		        		                  }
		        	               }
		        		   
		         }
		         
		    }
		      else
		         {
		        	 pst2=con.prepareStatement("select samplename from camp_donation_registered where cincharge=? and bloodgroup=? and AVAILABILITY=?");
		        	 pst2.setInt(1,inchargeid);
		        	 pst2.setString(2, bloodgroup);
		        	 pst2.setString(3,"yes");
		        	 ResultSet rs2=pst2.executeQuery();
		        	 while(rs2.next())
		        	 {
		        		 count++;
		        		 hospital.setSampleName(rs2.getString(1));
		        		 break;
		        	 }
		        	         if(count!=0)
		        	         {

		        			    	pst4=con.prepareStatement("update camp_donation_registered set AVAILABILITY=? where samplename=?");
		        			    	pst4.setString(1,"no");
		        			    	pst4.setString(2,hospital.getSampleName());
		        			        int count3=pst4.executeUpdate(); 
		        			         if(count3!=0)
		        			         {
		        			        	 pst1=con.prepareStatement("insert into HOSPITAL_RECEPTION_DETAILS values(?,?,?,?,sysdate)");
		        			        	 pst1.setInt(1,hid);
		        			        	 pst1.setInt(2, recipientid);
		        			        	 pst1.setString(3,recipientname);
		        			        	 pst1.setString(4,bloodgroup);
		        			        	 int count4=pst1.executeUpdate();
		        			        	   if(count4!=0)
		        			        	   {
		        			        		   st2=con.createStatement();
		        			        		   int check=st2.executeUpdate("update hospital_blood_requests set status='alloted' where brid='"+brid+"'");
		        			        		   if(check!=0)
		        			        		   {
		        			        		     con.commit();
		        			        		     flag=true;
		        			        		   }
		        			        	   }
		        			        		   
		        			         }
		        	        	 
		        	            }
		        	 
		               }
		    
		    if(count==0)
		    {
		    	
		    	st=con.createStatement();
		    	int check=st.executeUpdate("update hospital_blood_requests set status='not available' where brid="+brid);
		    	if(check!=0)
		    	{
		    		flag=true;
		    		con.commit();
		    		
		    	}
		    }
		    
	} 
	  catch (Exception e) {
		flag=false;
		e.printStackTrace();
		try {
		
			con.rollback();
			flag=false;
		} catch (Exception e1) {
			e1.printStackTrace();
			// TODO: handle exception
		}
		// TODO: handle exception
	}
	  return flag;
	  
  }
  public boolean rejectRequest(HospitalBean hospital)
  {
	  int brid=hospital.getBrid();
	  boolean flag=false;
	  try
	  {
	  st=con.createStatement();
  	  int check=st.executeUpdate("update hospital_blood_requests set status='not available' where brid='"+brid+"'");
  	  if(check!=0)
  	  {
  		  flag=true;
  		  
  	  }
	  
	  }catch (Exception e) {
		  e.printStackTrace();
		  flag=false;
		// TODO: handle exception
	}
	   return flag;
	  
  }

   public ArrayList<HospitalBean> getTransfusions()
   {
	   ArrayList<HospitalBean> Hlist=new ArrayList<HospitalBean>();
	   try {
		   st=con.createStatement();
		   ResultSet rs=st.executeQuery("select h.hname,hr.recipientname,hr.bloodgroup,hr.dos from hospitals h,HOSPITAL_RECEPTION_DETAILS hr where h.hid=hr.hid");
		   while(rs.next())
			{
				HospitalBean hospitalBean=new HospitalBean();
				hospitalBean.setHname(rs.getString(1));
				hospitalBean.setRecipientname(rs.getString(2));
				hospitalBean.setBloodGroup(rs.getString(3));
				hospitalBean.setDonationDate(DateWrapper.parseDate(rs.getDate(4)));
				Hlist.add(hospitalBean);
			}
			
	} catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	   return Hlist;
   }
   public ArrayList<HospitalBean> getDonorDonation(String donorname)
   {
	   ArrayList<HospitalBean> hlist=new ArrayList<HospitalBean>();
		  try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select h.hname,hd.donorname,hd.donationdate from hospitals h, HOSPITAL_DONATION_DETAILS hd where h.hid=hd.hid and hd.donorname='"+donorname+"'");
		  
			 while(rs.next())
			 {
				 HospitalBean hospital=new HospitalBean();
				 hospital.setHname(rs.getString(1));
				 hospital.setDname(rs.getString(2));
				 hospital.setDonationDate(DateWrapper.parseDate(rs.getDate(3)));
				 hlist.add(hospital);
			 }
		  } catch (Exception e) {
			// TODO: handle exception
		} 
		   
		   return hlist;
			  
   }

   
   public ArrayList<HospitalBean> getStatus(HospitalBean hospitalBean)
   {
   	 int recipientid=hospitalBean.getRecipientid();
   	   ArrayList<HospitalBean> hlist=new ArrayList<HospitalBean>();
   		  try {
   			Statement st=con.createStatement();
   			ResultSet rs=st.executeQuery("select bloodgroup,status from  HOSPITAL_BLOOD_REQUESTS where RECIPIENTID="+recipientid);
   		   while(rs.next())
   			 {
   				 HospitalBean hospital=new HospitalBean();
   				 hospital.setBloodGroup(rs.getString(1));
   				 hospital.setStatus(rs.getString(2));
   				 hlist.add(hospital);
   			 }
   		  } catch (Exception e) {
   			// TODO: handle exception
   		} 
   		   return hlist;
   	 }


}
