package com.kws.bloodbank.dao;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kws.bloodbank.bean.AwarenessCampBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.core.util.DateWrapper;
import com.sun.org.apache.regexp.internal.recompile;

public class AwarenessCampDAO  extends AbstractDataAccessObject{
    
	Connection con=null;
    PreparedStatement pst=null;
	PreparedStatement pst1=null;
	Statement st=null;
	public AwarenessCampDAO()
	{
        con=getConnection();
        System.out.println("Connection established");
	}
	
	public boolean postAwarenessCamp(AwarenessCampBean camp)
	{
	  boolean	flag=false;
	  System.out.println("i am in PostAwarenessCamp() method of AwarenessCampDAO");
	  try
	  {
         int  acid=getSequenceID("awarenesscamp", "acid");
	     System.out.println(acid);
		 pst=con.prepareStatement("insert into awarenesscamp values(?,?,?,?,?,?,?,?,?,?,?)");
		 pst.setInt(1, acid);
		 pst.setInt(2,camp.getAcinchargeid());
		 pst.setString(3,camp.getAcname());
		 pst.setString(4,DateWrapper.parseDate(camp.getAcdate()));
		 pst.setString(5,camp.getActime());
		 pst.setString(6,camp.getAclocation());
		 pst.setString(7,camp.getAccity());
		 pst.setString(8,camp.getAcdescription());
		 pst.setString(9, camp.getAcontact());
		 pst.setString(10, camp.getAcadress());
		 pst.setString(11,camp.getAstatus());
         int p=pst.executeUpdate();
		 if(p!=0)
		 {
			 flag=true;
		 }
		  
	  }catch (Exception e) {
		  flag=false;
		  e.printStackTrace();
		  // TODO: handle exception
	}
		return flag;
		
	}
	public ArrayList<AwarenessCampBean> getAwarenessCamps() {
		ArrayList<AwarenessCampBean> awareList = new ArrayList<AwarenessCampBean>();
		try
		{
			st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from awarenesscamp");
			while (rs.next())
			{
				AwarenessCampBean aware =new AwarenessCampBean();
				int acid=rs.getInt(1);
				aware.setAcid(acid);
				aware.setAcinchargeid(rs.getInt(2));
				aware.setAcname(rs.getString(3));			
				aware.setAcdate(com.kws.bloodbank.core.util.DateWrapper.parseDate(rs.getDate(4)));
				System.out.println(aware.getAcdate());
				aware.setActime(rs.getString(5));
				aware.setAclocation(rs.getString(6));
				aware.setAccity(rs.getString(7));
				aware.setAcdescription(rs.getString(8));
				aware.setAcontact(rs.getString(9));
				aware.setAcadress(rs.getString(10));
				aware.setAstatus(rs.getString(11));
			 /*  pst=con.prepareStatement("select sysdate-acdate from awarenesscamp where acid=?");
			   pst.setInt(1,acid);
			    ResultSet rs1=pst.executeQuery();
			    while(rs.next())
			    {
				    System.out.println("i am in rs.next");
				    aware.setCount(rs.getDouble(1));
				    System.out.println(aware.getCount());
				    
			     }
               */
				awareList.add(aware);
			  			
		    }
			
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return awareList;
		
	}

	public ArrayList<AwarenessCampBean> getAwarenessCamps(AwarenessCampBean accamp) {
		ArrayList<AwarenessCampBean> awareList = new ArrayList<AwarenessCampBean>();
		int vid=accamp.getAcinchargeid();
		try
		{
			pst=con.prepareStatement("select * from awarenesscamp where acincharge=?");
			pst.setInt(1,vid);
			ResultSet rs=pst.executeQuery();
			while (rs.next())
			{
				AwarenessCampBean aware =new AwarenessCampBean();
				int acid=rs.getInt(1);
				aware.setAcid(acid);
				aware.setAcinchargeid(rs.getInt(2));
				aware.setAcname(rs.getString(3));			
				aware.setAcdate(com.kws.bloodbank.core.util.DateWrapper.parseDate(rs.getDate(4)));
				System.out.println(aware.getAcdate());
				aware.setActime(rs.getString(5));
				aware.setAclocation(rs.getString(6));
				aware.setAccity(rs.getString(7));
				aware.setAcdescription(rs.getString(8));
				aware.setAcontact(rs.getString(9));
				aware.setAcadress(rs.getString(10));
				aware.setAstatus(rs.getString(11));
			 /*  pst=con.prepareStatement("select sysdate-acdate from awarenesscamp where acid=?");
			   pst.setInt(1,acid);
			    ResultSet rs1=pst.executeQuery();
			    while(rs.next())
			    {
				    System.out.println("i am in rs.next");
				    aware.setCount(rs.getDouble(1));
				    System.out.println(aware.getCount());
				    
			     }
               */
				awareList.add(aware);
			  			
		    }
			
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return awareList;
		
	}
	public boolean postCampDetails(AwarenessCampBean aware)
	{
		boolean flag=false;
		
		try
		{ 
			con.setAutoCommit(false);	
			pst=con.prepareStatement("insert into awareness_camp_details values(?,?,?,?,?)");
			pst.setInt(1,aware.getAcid());
			pst.setInt(2,aware.getAcinchargeid());
			pst.setString(3,aware.getFeedback());
			File f1=new File(aware.getPic1());
			FileInputStream fis1=new FileInputStream(f1);
			pst.setBinaryStream(4,fis1, (int)f1.length());
			File f2=new File(aware.getPic2());
			FileInputStream fis2=new FileInputStream(f2);
			pst.setBinaryStream(5, fis2,(int)f2.length());
			int i=pst.executeUpdate();
			if(i!=0)
			{
			   flag=true;
			   System.out.println("upload of awareness camp detatils is sucessful check status of awareness camp");
			   pst1=con.prepareStatement("update awarenesscamp set astatus=? where acid=?");
			   pst1.setString(1,"completed");
			   pst1.setInt(2,aware.getAcid());
			   int j=pst1.executeUpdate();
			     if(j!=0)
			     {  
			    	 flag=true;
			    	con.commit();
			    	System.out.println("satatus also sucessufully updated");
			     }
			     else
			     {
			    	 con.rollback();
			     }
			}    
			
			else
				flag=false;

		}catch (Exception e) {
			flag=false;
			try
			{
			con.rollback();
			}catch (Exception e1) {
				e1.printStackTrace();
				// TODO: handle exception
			}
			e.printStackTrace();
			// TODO: handle exception
		}
		
		return flag;
	}
	public ArrayList<AwarenessCampBean> getAwarenessCampDetails(String storepath,int acid)
	{
		ArrayList<AwarenessCampBean> awareDetails=new ArrayList<AwarenessCampBean>();
		int id1=1;
		int id2=1001;
		
		try
		{
		 Statement st=con.createStatement();
		 ResultSet rs=st.executeQuery("select * from AWARENESS_CAMP_DETAILS where acid="+acid);
		  while(rs.next())
		 {
			AwarenessCampBean aware=new AwarenessCampBean();
		    aware.setAcid(rs.getInt(1));
			aware.setAcinchargeid(rs.getInt(2));
			aware.setFeedback(rs.getString(3));
			Blob b=rs.getBlob(4);
			byte b1[]=b.getBytes(1, (int)b.length());
			OutputStream fout=new FileOutputStream(storepath+"/"+id1+".jpg");
			fout.write(b1);
			aware.setPic1(id1+".jpg");
			id1++;
			
		Blob blob=rs.getBlob(5);
		   byte b2[]=blob.getBytes(1,(int)blob.length());
		    fout=new FileOutputStream(storepath+"/"+id2+".jpg");
			fout.write(b2);
			aware.setPic2(id2+".jpg");
		    id2++;
		    awareDetails.add(aware);
		}
		
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}		
		return awareDetails;
		
	}
	public ArrayList<AwarenessCampBean> getHospitalActivities()
	{
		ArrayList<AwarenessCampBean> awareActivity=new ArrayList<AwarenessCampBean>();
		try
		{
			st=con.createStatement();
			ResultSet rs=st.executeQuery("select a.acname,a.aclocation,a.acdate,ad.acfeedback from awarenesscamp a,AWARENESS_CAMP_DETAILS  ad where a.acid=ad.acid");
			while(rs.next())
			{
				AwarenessCampBean camp =new AwarenessCampBean();
				camp.setAcname(rs.getString(1));
				camp.setAclocation(rs.getString(2));
				camp.setAcdate(DateWrapper.parseDate(rs.getDate(3)));
				camp.setFeedback(rs.getString(4));
				awareActivity.add(camp);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		
		return awareActivity;
		
		
	}	
	
	public int getCount()
	{
		
		 int count=0;
		try {			
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return count;
	}
	
}
