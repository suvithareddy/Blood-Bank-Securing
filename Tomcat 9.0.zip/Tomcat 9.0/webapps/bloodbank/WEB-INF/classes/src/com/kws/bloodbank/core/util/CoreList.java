package com.kws.bloodbank.core.util;

import java.util.ArrayList;
import java.util.Vector;

public class CoreList extends Vector
{

}
