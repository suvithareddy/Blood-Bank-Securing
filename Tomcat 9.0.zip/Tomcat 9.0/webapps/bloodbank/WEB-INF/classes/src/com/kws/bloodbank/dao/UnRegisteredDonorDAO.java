package com.kws.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import com.kws.bloodbank.bean.UnregisteredDonorBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;

public class UnRegisteredDonorDAO  extends AbstractDataAccessObject{
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	public UnRegisteredDonorDAO()
	{
		con=getConnection();
		System.out.println("connection established");
	}
	public boolean  donationDetails(UnregisteredDonorBean donor )
	{
		//UnRegisteredDonorBean donation= new UnregisteredDonorBean();
		boolean flag=false;
		
	    try
	    {
	    	int sampleid=getSequenceID("donation_camp_details","sampleid");
	    	pst=con.prepareStatement("insert into donation_camp_details values(?,?,?,?,?,?,?,?,?,?,?) ");
	    	pst.setInt(1,sampleid);
	    	pst.setString(2,donor.getSamplename());
	    	pst.setInt(3,donor.getCampid());
	    	pst.setInt(4,donor.getInchargeid());
	    	pst.setString(5, donor.getCampdonor());
	    	pst.setString(6,donor.getBloodgroup());
	    	pst.setString(7,donor.getContact());
	    	pst.setString(8,donor.getCity());
	    	pst.setString(9,donor.getAdress());
	    	pst.setString(10,donor.getSamplestatus());
	    	if(donor.getSamplestatus().equals("yes"))
	    	{
	    	pst.setString(11,donor.getSamplestatus());
	    	}
	    	else
	    		pst.setString(11,"no");
	    	int count=pst.executeUpdate();
	    	if(count!=0)
	   		flag=true;
	    	else
	    	flag=false;
	      }catch (Exception e) {
	    	flag=false;
			e.printStackTrace();
	    	// TODO: handle exception
		}
		 return flag;
	}

}
