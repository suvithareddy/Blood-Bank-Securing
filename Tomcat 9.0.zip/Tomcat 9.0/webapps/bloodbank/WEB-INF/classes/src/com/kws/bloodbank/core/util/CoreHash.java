package com.kws.bloodbank.core.util;

import java.util.Hashtable;

public class CoreHash extends Hashtable
{

}
