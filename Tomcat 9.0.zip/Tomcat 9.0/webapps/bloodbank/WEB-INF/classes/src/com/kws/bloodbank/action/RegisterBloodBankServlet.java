package com.kws.bloodbank.action;

import java.io.IOException;
import com.kws.bloodbank.dao.BloodBankDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.dao.BloodBankDAO;
import com.kws.bloodbank.dao.UserMasterDAO;

public class RegisterBloodBankServlet extends HttpServlet  {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
			{
		BloodBankBean bloodbank=new BloodBankBean();
		bloodbank.setBname(request.getParameter("bname"));
		bloodbank.setBlocation(request.getParameter("blocation"));
		bloodbank.setBcity(request.getParameter("bcity"));
		bloodbank.setBcontact(request.getParameter("bcontact"));
		bloodbank.setBadress(request.getParameter("badress"));
		bloodbank.setState(request.getParameter("bstate"));
		String bstate=request.getParameter("bstate");
		bloodbank.setInchargeId(Integer.parseInt(request.getParameter("volunteerid")));
		System.out.println("id...."+Integer.parseInt(request.getParameter("volunteerid")));
		
		System.out.println("values to the bloodbankbean class is sucessfully set in RegisterBloodBankServlet");
		BloodBankDAO blooddao=new BloodBankDAO();
         boolean flag=blooddao.registerBloodBank(bloodbank);
         if(flag)
          	  response.sendRedirect("AdminHome.jsp?status=Hospital Registration Success");
            else
          	  response.sendRedirect("AdminHome.jsp?status=Hospital Registration Failure");
		
	}

}
