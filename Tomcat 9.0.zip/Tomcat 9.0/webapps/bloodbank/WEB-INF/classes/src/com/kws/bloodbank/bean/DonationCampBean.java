package com.kws.bloodbank.bean;

public class DonationCampBean {
	private int cid;
	private String cname;
	private int cinchargeid;
	private String cinchargename;
	private String cdate ;
	private String ctime;
	private String clocation;
	private String ccity;
	private String cdescription;
	private String contact;
	private int sampleid;
	private String cdonor;
	private String registered;
	private String bloodgroup;
	private String Cadress;
	private String samplestatus;
	private String campstatus;
	private String samplename;
	private String available;
	
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public String getCampsatatus() {
		return campstatus;
	}
	public void setCampsatatus(String campstatus) {
		this.campstatus = campstatus;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getCinchargeid() {
		return cinchargeid;
	}
	public void setCinchargeid(int cinchargeid) {
		this.cinchargeid = cinchargeid;
	}
	public String getCinchargename() {
		return cinchargename;
	}
	public void setCinchargename(String cinchargename) {
		this.cinchargename = cinchargename;
	}
	public String getCdate() {
		return cdate;
	}
	public void setCdate(String cdate) {
		this.cdate = cdate;
	}
	public String getCtime() {
		return ctime;
	}
	public void setCtime(String ctime) {
		this.ctime = ctime;
	}
	public String getClocation() {
		return clocation;
	}
	public void setClocation(String clocation) {
		this.clocation = clocation;
	}
	public String getCcity() {
		return ccity;
	}
	public void setCcity(String ccity) {
		this.ccity = ccity;
	}
	public String getCdescription() {
		return cdescription;
	}
	public void setCdescription(String cdescription) {
		this.cdescription = cdescription;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getSampleid() {
		return sampleid;
	}
	public void setSampleid(int sampleid) {
		this.sampleid = sampleid;
	}
	public String getCdonor() {
		return cdonor;
	}
	public void setCdonor(String cdonor) {
		this.cdonor = cdonor;
	}
	public String getRegistered() {
		return registered;
	}
	public void setRegistered(String registered) {
		this.registered = registered;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getSamplestatus() {
		return samplestatus;
	}
	public void setSamplestatus(String samplestatus) {
		this.samplestatus = samplestatus;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCadress() {
		return Cadress;
	}
	public void setCadress(String cadress) {
		Cadress = cadress;
	}
	public String getCampstatus() {
		return campstatus;
	}
	public void setCampstatus(String campstatus) {
		this.campstatus = campstatus;
	}
	public String getSamplename() {
		return samplename;
	}
	public void setSamplename(String samplename) {
		this.samplename = samplename;
	}
	
}
