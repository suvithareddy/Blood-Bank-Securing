package com.kws.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import com.kws.bloodbank.bean.RegisteredDonorBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;

public class RegisteredDonorDAO extends AbstractDataAccessObject{
	

	Connection con=null;
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	Statement st=null;
	public  RegisteredDonorDAO() {
		con=getConnection();
		System.out.println("Connection established");
	}
	
	public boolean donationDetails(RegisteredDonorBean donor)
	{
	  boolean flag=false;
	  
	  try
	  {
		 int  sampleid=getSequenceID("camp_donation_registered","sampleid");
		 System.out.println(sampleid);
		 System.out.println(donor.getCampid());
		 System.out.println(donor.getInchargeid());
		 System.out.println(donor.getCampdonorid());
		 System.out.println(donor.getBloodgroup());
		 System.out.println(donor.getSamplestatus());
		 System.out.println(donor.getSamplename());
		 
		pst=con.prepareStatement("insert into camp_donation_registered values(?,?,?,?,?,?,?,?)");
		pst.setInt(1,sampleid);
		pst.setInt(2,donor.getCampid());
		pst.setInt(3,donor.getInchargeid());
		pst.setInt(4,donor.getCampdonorid());
		pst.setString(5,donor.getBloodgroup());
		pst.setString(6,donor.getSamplestatus());
		pst.setString(7,donor.getSamplename());
		if(donor.getSamplestatus().equals("yes"))
		{
		pst.setString(8,donor.getSamplestatus());
		}
		else
			pst.setString(8,"no");
		int count=pst.executeUpdate();
		if(count!=0)
			flag=true;
		else
			flag=false;
	}catch (Exception e) {
		flag=false;
		e.printStackTrace();
	}
	  return flag;
	  
	}
		


}
