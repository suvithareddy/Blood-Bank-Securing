package com.kws.bloodbank.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kws.bloodbank.bean.NewsBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.core.util.DateWrapper;

public class NewsDAO  extends  AbstractDataAccessObject
{
    
	Connection con=null;
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	Statement st=null;
	public NewsDAO()
	{
		con=getConnection();
		System.out.println("Connection established");
	}

	
	public boolean postNews(NewsBean news)
	{
		boolean flag=false;
	int 	newsid=getSequenceID("news", "newsid");
		try {
			pst=con.prepareStatement("insert into news values(?,?,?,?,?,sysdate)");
            pst.setInt(1,newsid);
            pst.setString(2,news.getHeader());
            pst.setString(3,news.getDescription());
            File f1=new File(news.getImage());
            FileInputStream fis1=new FileInputStream(f1);
            pst.setBinaryStream(4,fis1,(int)f1.length());
            File f2=new File(news.getDoc());
            FileInputStream fis2=new FileInputStream(f2);
            pst.setBinaryStream(5,fis2,(int)f2.length());
            int i=pst.executeUpdate();
            if(i!=0)
            {
            	flag=true;
            }
            
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return flag;
	}
	public ArrayList<NewsBean> getNews(String storepath)
	{
		ArrayList<NewsBean> news =new ArrayList<NewsBean>();
	  try {
		  int id1=3001;
		  int id2=2001;
		  Statement st=con.createStatement();
		  ResultSet rs=st.executeQuery("select * from news");
		  while(rs.next())
		  {
			  NewsBean newsBean=new NewsBean();
			  newsBean.setNewsid(rs.getInt(1));
			  newsBean.setHeader(rs.getString(2));
			  newsBean.setDescription(rs.getString(3));
			  Blob b=rs.getBlob(4);
				byte b1[]=b.getBytes(1, (int)b.length());
				OutputStream fout=new FileOutputStream(storepath+"/"+id1+".gif");
				fout.write(b1);
				newsBean.setImage(id1+".gif");
				id1++;
				Blob blob=rs.getBlob(5);
				byte b2[]=blob.getBytes(1,(int)blob.length());
				OutputStream fout1=new FileOutputStream(storepath+"/"+id2+".doc");
				fout1.write(b2);
				newsBean.setDoc(id2+".doc");
				id2++;
				newsBean.setDate(DateWrapper.parseDate(rs.getDate(6)));
			 news.add(newsBean);
		  }
		  
		  
			
		  } catch (Exception e) {
			// TODO: handle exception
		}
		return news;
	}
	
}
