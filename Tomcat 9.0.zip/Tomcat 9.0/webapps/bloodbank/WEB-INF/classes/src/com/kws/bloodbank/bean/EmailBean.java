package com.kws.bloodbank.bean;

public class EmailBean {
	private int  emailid;
	private int  senderid;
	private int receiverid;
	private String senddate;
	private String subject;
	private String emaildesc;
	private String sendername;

	
	public String getSendername() {
		return sendername;
	}
	public void setSendername(String sendername) {
		this.sendername = sendername;
	}
	public int getEmailid() {
		return emailid;
	}
	public void setEmailid(int emailid) {
		this.emailid = emailid;
	}
	public int getSenderid() {
		return senderid;
	}
	public void setSenderid(int senderid) {
		this.senderid = senderid;
	}
	public int getReceiverid() {
		return receiverid;
	}
	public void setReceiverid(int receiverid) {
		this.receiverid = receiverid;
	}
	public String getSenddate() {
		return senddate;
	}
	public void setSenddate(String senddate) {
		this.senddate = senddate;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getEmaildesc() {
		return emaildesc;
	}
	public void setEmaildesc(String emaildesc) {
		this.emaildesc = emaildesc;
	}
	
	

}
