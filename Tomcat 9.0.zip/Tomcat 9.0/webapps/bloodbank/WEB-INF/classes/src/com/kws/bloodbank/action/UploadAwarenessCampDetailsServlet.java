package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.AwarenessCampBean;
import com.kws.bloodbank.dao.AwarenessCampDAO;

public class UploadAwarenessCampDetailsServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		int cid=Integer.parseInt(request.getParameter("acampid"));
		int vid=Integer.parseInt(request.getParameter("inchargeid"));
		String feedback=request.getParameter("feedback");
		String pic1=request.getParameter("path1");
		String pic2=request.getParameter("path2");
		AwarenessCampBean aware=new AwarenessCampBean();
		aware.setAcid(cid);
		aware.setAcinchargeid(vid);
		aware.setFeedback(feedback);
		aware.setPic1(pic1);
		aware.setPic2(pic2);
		aware.setAstatus("completed");
         boolean flag=new AwarenessCampDAO().postCampDetails(aware);
         String target=null;
         if(flag)
        	 target="UploadAwarenessCamps.jsp?status=upload sucessful";
         else
        	 target="UploadAwarenessCamps.jsp?status=upload failure";
         response.sendRedirect(target);
         
         
	}

}
