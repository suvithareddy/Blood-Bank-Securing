package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.EmailBean;
import com.kws.bloodbank.dao.EmailDAO;
import com.kws.bloodbank.dao.UserMasterDAO;

public class EmailActionServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmailBean email=new EmailBean();
		email.setEmaildesc(request.getParameter("maildesc"));
		email.setReceiverid(Integer.parseInt(request.getParameter("receiverid")));
		email.setSenderid(Integer.parseInt(request.getParameter("senderid")));
		email.setSubject(request.getParameter("subject"));
		boolean flag=new EmailDAO().sendEmails(email);
		String target=null;
		if(flag)
		{
			target="Emails.jsp?status=sent sucessfully";
		}
		else
		{
			target="Emails.jsp?status=sending failure";
		}
		
		response.sendRedirect(target);
	}

}
