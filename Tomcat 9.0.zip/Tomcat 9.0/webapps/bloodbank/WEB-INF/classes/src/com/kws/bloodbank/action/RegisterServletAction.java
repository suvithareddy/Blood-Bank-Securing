package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kws.bloodbank.bean.UserMasterBean;
import com.kws.bloodbank.dao.UserMasterDAO;

public class RegisterServletAction extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserMasterBean userMasterBean=new UserMasterBean();
		
        
		   userMasterBean.setUsername(request.getParameter("username"));
		   userMasterBean.setPassword(request.getParameter("password"));
		    userMasterBean.setType(request.getParameter("type"));
		   userMasterBean.setStatus("pending");
			userMasterBean.setFirstname(request.getParameter("firstname"));
			userMasterBean.setLastname(request.getParameter("lastname"));
			userMasterBean.setDob(request.getParameter("dob"));
			userMasterBean.setGender(request.getParameter("gender"));
			userMasterBean.setBloodgroup(request.getParameter("bloodgroup"));
			userMasterBean.setLocation(request.getParameter("location"));
			userMasterBean.setCity(request.getParameter("city"));
			userMasterBean.setState(request.getParameter("state"));
			userMasterBean.setContactno(request.getParameter("contactno"));
			userMasterBean.setPin(request.getParameter("pin"));
			userMasterBean.setEmail(request.getParameter("emailid"));
			userMasterBean.setAdress(request.getParameter("adress"));
			userMasterBean.setSecurityques(request.getParameter("squest"));
			userMasterBean.setSecurityans(request.getParameter("sanswer"));
			
		  System.out.println("values to the usermasterbean class is sucessfully set in RegisterActionServlet");
          UserMasterDAO userMasterDAO=new UserMasterDAO();
          boolean flag=userMasterDAO.registerUser(userMasterBean);
          if(flag)
        	  response.sendRedirect("RegisterUser.jsp?status=User Registration Success");
          else
        	  response.sendRedirect("RegisterUser.jsp?status=User Registration Failure");
		
	}

}
