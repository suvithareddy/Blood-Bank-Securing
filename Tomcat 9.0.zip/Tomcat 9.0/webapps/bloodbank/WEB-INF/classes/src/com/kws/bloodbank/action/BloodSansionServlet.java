package com.kws.bloodbank.action;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.BloodBankDAO;
import com.kws.bloodbank.dao.HospitaDAO;

public class BloodSansionServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	      String no=request.getParameter("inchargeid");
		 int inchargeid=Integer.parseInt(no);
		 int  recipientid=Integer.parseInt(request.getParameter("recipientid"));
         String bloodgroup=request.getParameter("bloodgroup").intern();
         System.out.println(request.getParameter("bloodgroup"));
		 if(bloodgroup.equalsIgnoreCase("AB"))
			 bloodgroup="AB+ve";
		 if(bloodgroup.equalsIgnoreCase("AB"))
			 bloodgroup="AB+ve";
			 
		 if(bloodgroup.equalsIgnoreCase("A"))
			 bloodgroup="A+ve";
		 if(bloodgroup.equalsIgnoreCase("B"))
			 bloodgroup="B+ve";
		 if(bloodgroup.equalsIgnoreCase("O"))
			 bloodgroup="O+ve";
		 if(bloodgroup.equals("A1"))
			 bloodgroup="A1+ve";
		 if(bloodgroup.equals("A2"))
			 bloodgroup="A2+ve";
		 if(bloodgroup.equals("A1B"))
			 bloodgroup="A1B+ve";
		 if(bloodgroup.equals("A2B"))
			 bloodgroup="A2B+ve";
		 
		 
		 
		 if(bloodgroup.equalsIgnoreCase("AB ve"))
			 bloodgroup="AB+ve";
		 if(bloodgroup.equalsIgnoreCase("AB ve"))
			 bloodgroup="AB+ve";
			 
		 if(bloodgroup.equalsIgnoreCase("A ve"))
			 bloodgroup="A+ve";
		 if(bloodgroup.equalsIgnoreCase("B ve"))
			 bloodgroup="B+ve";
		 if(bloodgroup.equalsIgnoreCase("O ve"))
			 bloodgroup="O+ve";
		 if(bloodgroup.equals("A1 ve"))
			 bloodgroup="A1+ve";
		 if(bloodgroup.equals("A2 ve"))
			 bloodgroup="A2+ve";
		 if(bloodgroup.equals("A1B ve"))
			 bloodgroup="A1B+ve";
		 if(bloodgroup.equals("A2B ve"))
			 bloodgroup="A2B+ve";
         String recipientname=request.getParameter("recipientname"); 
         int brid=Integer.parseInt(request.getParameter("brid"));
         boolean flag=false;
		 
		        HospitaDAO hospitaDAO=new HospitaDAO();
		        BloodBankDAO bloodBankDAO=new BloodBankDAO();
		        if(request.getParameter("type").equals("hospital"))
		         {
		         	        	
                   int hid=Integer.parseInt(request.getParameter("hid"));
                   
                   HospitalBean hospital=new HospitalBean();
                   hospital.setInchargeId(inchargeid);
                   hospital.setHid(hid);
                   hospital.setRecipientid(recipientid);
                   hospital.setBloodGroup(request.getParameter("bloodgroup"));
                   hospital.setRecipientname(recipientname);
                   hospital.setBrid(brid);
		        	
		        	
		        	if(request.getParameter("submit").equalsIgnoreCase("yes"))
		    		 {
                            
                           
                           flag= hospitaDAO.sansionBlood(hospital);
                            if(flag=true)
                              response.sendRedirect("VolunteerHome.jsp?status=Blood sansion sucessful");
                            else
                            	response.sendRedirect("VolunteerHome.jsp?status=Blood sansion failure");
		              }
		        	  else
		        	  {
                          flag= hospitaDAO.rejectRequest(hospital);
                          if(flag=true)
                              response.sendRedirect("VolunteerHome.jsp?status=Blood sansion Rejection sucessful");
                            else
                            	response.sendRedirect("VolunteerHome.jsp?status=Blood sansion Rejection  failure");
		        		  
		        	  }
		         }
		        
		        if(request.getParameter("type").equals("bloodbank"))
		         {
		        	
		        		        	
                    int bid=Integer.parseInt(request.getParameter("bid"));
                    BloodBankBean bloodBankBean=new BloodBankBean();
                    bloodBankBean.setInchargeId(inchargeid);
                    bloodBankBean.setBid(bid);
                    bloodBankBean.setRecipientid(recipientid);
                    bloodBankBean.setBloodGroup(request.getParameter("bloodgroup"));
                    bloodBankBean.setRecipientname(recipientname);
                    bloodBankBean.setBrid(brid);

		        	  if(request.getParameter("submit").equalsIgnoreCase("yes"))
		    		 {
		        		flag= bloodBankDAO.sansionBlood(bloodBankBean);
		        		 if(flag=true)
                             response.sendRedirect("VolunteerHome.jsp?status=Blood sansion sucessful");
                           else
                           	response.sendRedirect("VolunteerHome.jsp?status=Blood sansion failure");
		              }
		        	  else
		        	  {
		        		  flag= bloodBankDAO.rejectRequest(bloodBankBean);
		        		  if(flag=true)
                              response.sendRedirect("VolunteerHome.jsp?status=Blood sansion Rejection sucessful");
                            else
                            	response.sendRedirect("VolunteerHome.jsp?status=Blood sansion Rejection  failure");
		        	  }
		         }
		        
		        
  }
	    
	
}
