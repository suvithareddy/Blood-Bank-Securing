package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.DonationCampBean;
import com.kws.bloodbank.dao.DonationCampDAO;

public class PostCampServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
			{
		System.out.println("im in doPost of PostCampServlet");
	    String timing=request.getParameter("morning")+" "+"to"+" "+request.getParameter("evening");
	    DonationCampBean camp =new DonationCampBean();
		camp.setCname(request.getParameter("cname"));
		camp.setCdate(request.getParameter("cdate"));
		camp.setCtime(timing);
		camp.setClocation(request.getParameter("clocation"));
        camp.setCcity(request.getParameter("ccity"));
	    camp.setContact(request.getParameter("ccontact"));
	    camp.setCdescription(request.getParameter("cdescription"));
	    camp.setCampsatatus("pending");
	    HttpSession session=request.getSession();
	    Integer i=(Integer)session.getAttribute("userid");
	    int k=i.intValue();
	    camp.setCinchargeid(k);
	    camp.setCadress(request.getParameter("cadress"));
	    System.out.println("values sucessfully set in PostCampServlet");
	    boolean flag=new DonationCampDAO().postCamp(camp);
	    if(flag)
	    {
	    	response.sendRedirect("PostBloodDonationCamps.jsp?status=post sucessful");
	    }
	    else
	    {
	    	response.sendRedirect("PostBloodDonationCamps.jsp?status=post failure");
	    }
	 }
  }


