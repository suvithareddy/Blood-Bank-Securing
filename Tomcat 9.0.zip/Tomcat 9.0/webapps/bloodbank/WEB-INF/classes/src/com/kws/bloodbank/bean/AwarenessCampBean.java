package com.kws.bloodbank.bean;

public class AwarenessCampBean {
 private int acid;
 private String acname;
 private int acinchargeid;
 private String acdate;
 private String  actime;
 private String aclocation;
 private String accity;
 private String acdescription;
 private String acontact;
 private String acadress;
 private String astatus;
 private String feedback;
 private String pic1;
 private String pic2;
 private double count;
 private String available;
public String getAvailable() {
	return available;
}
public void setAvailable(String available) {
	this.available = available;
}
public double getCount() {
	return count;
}
public void setCount(double count) {
	this.count = count;
}
public int getAcid() {
	return acid;
}
public void setAcid(int acid) {
	this.acid = acid;
}
public String getAcname() {
	return acname;
}
public void setAcname(String acname) {
	this.acname = acname;
}
public int getAcinchargeid() {
	return acinchargeid;
}
public void setAcinchargeid(int acinchargeid) {
	this.acinchargeid = acinchargeid;
}
public String getAcdate() {
	return acdate;
}
public void setAcdate(String acdate) {
	this.acdate = acdate;
}
public String getActime() {
	return actime;
}
public void setActime(String actime) {
	this.actime = actime;
}
public String getAclocation() {
	return aclocation;
}
public void setAclocation(String aclocation) {
	this.aclocation = aclocation;
}
public String getAccity() {
	return accity;
}
public void setAccity(String accity) {
	this.accity = accity;
}
public String getAcdescription() {
	return acdescription;
}
public void setAcdescription(String acdescription) {
	this.acdescription = acdescription;
}
public String getAcontact() {
	return acontact;
}
public void setAcontact(String acontact) {
	this.acontact = acontact;
}
public String getAcadress() {
	return acadress;
}
public void setAcadress(String acadress) {
	this.acadress = acadress;
}
public String getAstatus() {
	return astatus;
}
public void setAstatus(String astatus) {
	this.astatus = astatus;
}
public String getFeedback() {
	return feedback;
}
public void setFeedback(String feedback) {
	this.feedback = feedback;
}
public String getPic1() {
	return pic1;
}
public void setPic1(String pic1) {
	this.pic1 = pic1;
}
public String getPic2() {
	return pic2;
}
public void setPic2(String pic2) {
	this.pic2 = pic2;
}
 }
