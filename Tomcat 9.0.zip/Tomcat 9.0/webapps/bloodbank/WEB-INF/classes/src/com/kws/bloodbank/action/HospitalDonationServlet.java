package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.HospitaDAO;

public class HospitalDonationServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String status=request.getParameter("accepted");
		String samplename=request.getParameter("samplename");
		String bloodgroup=request.getParameter("bloodgroup");
		HttpSession session=request.getSession();
		int inchargeid=(Integer)(session.getAttribute("userid"));
		int hid=Integer.parseInt(request.getParameter("hid"));
		int drid=Integer.parseInt(request.getParameter("drid"));
		String donorname=request.getParameter("donorname");
		HospitalBean hospital=new HospitalBean();
		hospital.setStatus(status);
		hospital.setDrid(drid);
		hospital.setHid(hid);
		hospital.setInchargeId(inchargeid);
		hospital.setSampleName(samplename);
		hospital.setBloodGroup(bloodgroup);
		hospital.setDname(donorname);
		hospital.setStatus(request.getParameter("accepted"));
		boolean flag=false;
		HospitaDAO hospitalDAO=new HospitaDAO();
		flag=hospitalDAO.donationDetails(hospital);
		String target=null;
		if(flag)
			response.sendRedirect("VolunteerHome.jsp?status=upload sucessful");
		else 
			response.sendRedirect("VolunteerHome.jsp?status=upload failure");
		//RequestDispatcher rd=request.getRequestDispatcher(target);
		//rd.forward(request, response);
		
	   }

}
