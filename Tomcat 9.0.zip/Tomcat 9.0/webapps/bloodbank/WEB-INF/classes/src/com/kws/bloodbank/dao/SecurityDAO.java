package com.kws.bloodbank.dao;
import com.kws.bloodbank.bean.UserMasterBean;

import com.kws.bloodbank.core.util.DateWrapper;
import com.kws.bloodbank.core.util.DataObject;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.core.db.DBFactory;
import com.kws.bloodbank.core.util.LoggerManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

public class SecurityDAO extends AbstractDataAccessObject
{
	private Connection con;
    private String desc;
    private boolean flag=false;
   /** Creates a new instance of SecurityDAO */
    
    
    public SecurityDAO() 
    {
       
               //getting Database Connection
               con=getConnection();
               System.out.println(con);
               System.out.println("Connection established");
    }
    public String loginCheck(UserMasterBean userMasterBean)
    {
      String username=userMasterBean.getUsername();
        String password=userMasterBean.getPassword();
        int userid=userMasterBean.getUserid();
        String type="";
        System.out.println("i am in SecurityDAo class in loginCheck method");
        try
        {
            con.setAutoCommit(true);
            //PreparedStatement pst=con.prepareStatement("select * from usermaster where username=? and password=? and status=1");
            PreparedStatement pst=con.prepareStatement("select * from usermaster where userid=?");
            
            //pst.setString(1,username);
            //pst.setString(2,password);
            pst.setInt(1, userid);
           ResultSet rs=pst.executeQuery();
            System.out.println("sql executed sucessfully");
            if(rs.next())
            {
                /*Statement st=con.createStatement();
                st.executeUpdate("Update login_details set firstlogin=1 where loginname='"+loginid+"'");*/
                type=rs.getString(4);
                System.out.println("the user"+username +" "+"is presernt in the database");
                desc="Login Success";
            }
            else
            {
                flag=false;
                desc="Entered Invalid password";
                System.out.println("i am in else");
            }
        }
        catch (SQLException ex) 
        {
        	LoggerManager.writeLogSevere(ex);
            desc="Database Connection problem";
            System.out.println("i thrown into catch in securityDAO class login check method");
            flag=false;
        }
        
        //loginaudit(loginid,desc);
        return type;
    }
    
    
    // Method of changing the password
    
    public boolean changePassword(UserMasterBean usermaster)
    {
        String username=usermaster.getUsername();
        String oldpassword=usermaster.getPassword();
        String newpassword=usermaster.getNewPassword();
        
        try 
        {
            con.setAutoCommit(false);
            String newdate=DateWrapper.parseDate(new Date());
            PreparedStatement pst=con.prepareStatement("UPDATE usermaster SET password=? WHERE username=? and password=?");
            
            pst.setString(1,newpassword);
            
            pst.setString(2,username);
            pst.setString(3,oldpassword);
            
            int i=pst.executeUpdate();
            if(i==1)
            {
                flag=true;
                con.commit();
            }
            else
            {
                flag=false;
                con.rollback();
            }
        } 
        catch (SQLException ex) 
        {
        	LoggerManager.writeLogSevere(ex);
            flag=false;
            try 
            {
                con.rollback();
            } 
            catch (SQLException sex) 
            {
            	LoggerManager.writeLogSevere(sex);
            }
        }
        catch (Exception e) 
        {
            e.printStackTrace();
            flag=false;
            try 
            {
                con.rollback();
            } 
            catch (SQLException sex) 
            {
            	LoggerManager.writeLogSevere(sex);
            }
        }
        System.out.println(flag);
        return flag;        
    }
    
    

}
