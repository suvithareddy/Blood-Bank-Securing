package com.kws.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.bean.EmailBean;
import com.kws.bloodbank.core.util.DateWrapper;
public class EmailDAO extends AbstractDataAccessObject{
	
	Connection con=null;
	PreparedStatement ps=null;
	Statement st=null;
	ResultSet rs=null;
	public boolean sendEmails(EmailBean emailBean){
		boolean flag=false;
		try{
			int eid=getSequenceID("emails", "emailid");
			con=getConnection();
			ps=con.prepareStatement("insert into emails values(?,?,?,sysdate,?,?)");
			ps.setInt(1,eid);
			ps.setInt(2,emailBean.getSenderid());
			ps.setInt(3,emailBean.getReceiverid());
			ps.setString(4,emailBean.getSubject());
			ps.setString(5,emailBean.getEmaildesc());
			int count=ps.executeUpdate();
			if(count>0)
				flag=true;
			
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return flag;
	}
	public ArrayList<EmailBean> receivedEmails(int rid){
		ArrayList<EmailBean> emailsList=new ArrayList<EmailBean>();
		try{
			con=getConnection();
			st=con.createStatement();
			rs=st.executeQuery("select e.emailid,e.senderid,e.receiverid,e.subject,e.description,e.senddate,u.username from emails e,usermaster u where e.senderid=u.userid and e.receiverid="+rid);
			EmailBean emailBean=null;
			while(rs.next()){
				emailBean=new EmailBean();
				emailBean.setEmailid(rs.getInt(1));
				emailBean.setSenderid(rs.getInt(2));
				emailBean.setReceiverid(rs.getInt(3));
				emailBean.setSubject(rs.getString(4));
				emailBean.setEmaildesc(rs.getString(5));
				emailBean.setSenddate(DateWrapper.parseDate(rs.getDate(6)));
				emailBean.setSendername(rs.getString(7));
				emailsList.add(emailBean);
			}
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		
		return emailsList;
	}
	public boolean deleteEmail(int eid){
		boolean flag=false;
		try{
			con=getConnection();
			ps=con.prepareStatement("delete from emails where emailid=?");
			ps.setInt(1,eid);
			int count=ps.executeUpdate();
			if(count>0)
				flag=true;
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return flag;
	}
	

}

	


