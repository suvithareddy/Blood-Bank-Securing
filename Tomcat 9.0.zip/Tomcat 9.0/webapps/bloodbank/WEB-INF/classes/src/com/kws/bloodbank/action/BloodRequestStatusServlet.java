package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.BloodBankDAO;
import com.kws.bloodbank.dao.HospitaDAO;

public class BloodRequestStatusServlet extends HttpServlet {
public void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
String type=request.getParameter("bloodrequest");
HttpSession session=request.getSession();
int recipientid=(Integer)(session.getAttribute("userid"));
BloodBankBean bloodBankBean =new BloodBankBean();
HospitalBean hospitalBean=new HospitalBean();
bloodBankBean.setRecipientid(recipientid);
hospitalBean.setRecipientid(recipientid);
String target=null;
if(type.equalsIgnoreCase("bloodbank")){
BloodBankDAO bloodBankDAO=new BloodBankDAO();

ArrayList<BloodBankBean> bloodBank=bloodBankDAO.getStatus(bloodBankBean);
session.setAttribute("bloodbankRequestStatus",bloodBank );
response.sendRedirect("BloodBankRequests.jsp");
}

 else if(type.equalsIgnoreCase("hospital"))
   {
   HospitaDAO hospitaDAO=new HospitaDAO();
 
   ArrayList<HospitalBean> hospital=  hospitaDAO.getStatus(hospitalBean);
   session.setAttribute("hospitalRequestStatus",hospital);
   response.sendRedirect("HospitalRequests.jsp");
    }
}
}
