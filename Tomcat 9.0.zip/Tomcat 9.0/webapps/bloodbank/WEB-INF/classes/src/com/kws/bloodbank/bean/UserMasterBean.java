package com.kws.bloodbank.bean;

public class UserMasterBean {
  private int userid;
  private String username;
  private String password;
  private String type;
  private String  status;
  private String firstname;
  private String lastname;
  private String dor;
  private String dob;
  private String gender;
  private String bloodgroup;
  private String location;
  private String city;
  private String state;
  private  String contactno;
  private String email;
  private  String pin;
  private String adress;
  private String securityques;
  private String securityans;
  private String newPassword;
  private String available;
  
  public String getAvailable() {
	return available;
}


public void setAvailable(String available) {
	this.available = available;
}


public String getNewPassword() {
	return newPassword;
}


public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
}


public String getSecurityques() {
	return securityques;
}


public void setSecurityques(String securityques) {
	this.securityques = securityques;
}


public String getSecurityans() {
	return securityans;
}


public void setSecurityans(String securityans) {
	this.securityans = securityans;
}


public UserMasterBean()
  {
	  System.out.println("UserMasterBean class constructor");
  }
  
  
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getDor() {
	return dor;
}
public void setDor(String dor) {
	this.dor = dor;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getBloodgroup() {
	return bloodgroup;
}
public void setBloodgroup(String bloodgroup) {
	this.bloodgroup = bloodgroup;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getAdress() {
	return adress;
}
public void setAdress(String adress) {
	this.adress = adress;
}
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getContactno() {
	return contactno;
}
public void setContactno(String contactno) {
	this.contactno = contactno;
}
public String getPin() {
	return pin;
}
public void setPin(String pin) {
	this.pin = pin;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
}
