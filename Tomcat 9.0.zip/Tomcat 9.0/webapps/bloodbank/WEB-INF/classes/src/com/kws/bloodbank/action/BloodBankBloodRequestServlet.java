package com.kws.bloodbank.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.dao.BloodBankDAO;

public class BloodBankBloodRequestServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		String recipientName=(String)(session.getAttribute("user"));
		int recipientid=(Integer)(session.getAttribute("userid"));
		String bloodgroup=request.getParameter("bloodgroup");
		int bid=Integer.parseInt(request.getParameter("bloodbank"));
		BloodBankBean bloodbank=new BloodBankBean();
		bloodbank.setRname(recipientName);
		bloodbank.setRid(recipientid);
		bloodbank.setBloodGroup(bloodgroup);
		bloodbank.setBid(bid);
		String target=null;
		boolean flag=new BloodBankDAO().postBloodRequest(bloodbank);
		if(flag)
		
			response.sendRedirect("RecipientHome.jsp?status=Request posted sucessfully");
		else
			response.sendRedirect("RecipientHome.jsp?status=Request posting failure");
		
		//request.getRequestDispatcher(target).forward(request, response);
		
		 

	}

}
