package com.kws.bloodbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.kws.bloodbank.bean.AwarenessCampBean;
import com.kws.bloodbank.bean.DonationCampBean;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
import com.kws.bloodbank.core.util.DateWrapper;

public class DonationCampDAO extends AbstractDataAccessObject{
    
	
	Connection con=null;
	PreparedStatement pst=null;
	Statement st=null;
	public DonationCampDAO()
	{

		con=getConnection();
        System.out.println("Connection established");
	}
	
	public boolean postCamp(DonationCampBean campbean)
	{
		
	    boolean	flag=false;
	   System.out.println("i am in PostCamp() method of DonationCampDAO");
	  try
	  {
         
		  
		 int  cid=getSequenceID("donationcamp", "cid");
	     System.out.println(cid);
		 pst=con.prepareStatement("insert into donationCamp values(?,?,?,?,?,?,?,?,?,?,?)");
		 pst.setInt(1, cid);
		 pst.setInt(2,campbean.getCinchargeid());
		 pst.setString(3,campbean.getCname());
		 pst.setString(4,DateWrapper.parseDate(campbean.getCdate()));
		 pst.setString(5,campbean.getCtime());
		 pst.setString(6,campbean.getClocation());
		 pst.setString(7,campbean.getCcity());
		 pst.setString(8,campbean.getCdescription());
		 pst.setString(9, campbean.getContact());
		 pst.setString(10, campbean.getCadress());
		 pst.setString(11,campbean.getCampsatatus());
         int p=pst.executeUpdate();
		 if(p!=0)
		 {
			 flag=true;
		 }
		  
	  } 
	  catch (Exception e)
	  {
		  flag=false;
		  e.printStackTrace();
		  
	  }
		return flag;
		
	}
	
	public ArrayList<DonationCampBean> getDonationCamps() {
		ArrayList<DonationCampBean> dList = new ArrayList<DonationCampBean>();
		try
		{
			st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from DONATIONCAMP");
			while (rs.next())
			{
				DonationCampBean dcamp= new DonationCampBean();
				dcamp.setCid(rs.getInt(1));
				dcamp.setCinchargeid(rs.getInt(2));
				dcamp.setCname(rs.getString(3));
				dcamp.setCdate(DateWrapper.parseDate(rs.getDate(4)));
				dcamp.setCtime(rs.getString(5));
				dcamp.setClocation(rs.getString(6));
				dcamp.setCcity(rs.getString(7));
				dcamp.setCdescription(rs.getString(8));
				dcamp.setContact(rs.getString(9));
				dcamp.setCadress(rs.getString(10));
				dcamp.setCampsatatus(rs.getString(11));
				dList.add(dcamp);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return dList;
		
	}
	
	
	
	public ArrayList<DonationCampBean> getDonationCamps(DonationCampBean camp) {
		ArrayList<DonationCampBean> dList = new ArrayList<DonationCampBean>();
		int vid=camp.getCinchargeid();
		System.out.println(vid);
		try
		{
			pst=con.prepareStatement("select * from donationcamp where cincharge=?");
			pst.setInt(1,vid);
			ResultSet rs=pst.executeQuery();
			while (rs.next())
			{
				  
				DonationCampBean dcamp= new DonationCampBean();
				dcamp.setCid(rs.getInt(1));
				dcamp.setCinchargeid(rs.getInt(2));
				dcamp.setCname(rs.getString(3));
				dcamp.setCdate(DateWrapper.parseDate(rs.getDate(4)));
				dcamp.setCtime(rs.getString(5));
				dcamp.setClocation(rs.getString(6));
				dcamp.setCcity(rs.getString(7));
				dcamp.setCdescription(rs.getString(8));
				dcamp.setContact(rs.getString(9));
				dcamp.setCadress(rs.getString(10));
				dcamp.setCampsatatus(rs.getString(11));
				dList.add(dcamp);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return dList;
		
	}
	
	
	
	
	
	public boolean updationFinished(DonationCampBean donation)
	{
		boolean flag=false;
		System.out.println();
		try
		{
			pst=con.prepareStatement("update  donationcamp set status=? where cid=?");
			pst.setString(1,"completed");
			pst.setInt(2,donation.getCid());
			int count=pst.executeUpdate();
			if(count!=0)
			flag=true;
			else
			flag=false;
		}
		catch (Exception e) {
			flag=false;
			e.printStackTrace();
			}
		return flag;
		
	}
	
	

}
