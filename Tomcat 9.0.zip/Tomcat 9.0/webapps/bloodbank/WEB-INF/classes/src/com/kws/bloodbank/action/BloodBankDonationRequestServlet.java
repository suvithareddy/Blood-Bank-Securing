package com.kws.bloodbank.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.BloodBankBean;
import com.kws.bloodbank.dao.BloodBankDAO;

public class BloodBankDonationRequestServlet extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        HttpSession session = request.getSession();
	    int bid = Integer.parseInt(request.getParameter("bloodbankid"));
		int donorid = (Integer) (session.getAttribute("userid"));
		System.out.println(donorid);
		String dname = (String) (session.getAttribute("user"));
		
		String target ="DonorHome.jsp?status=Donation Request Rejected";
		BloodBankBean blood=new BloodBankBean();
	
		blood.setBid(bid);
		blood.setDid(donorid);
		blood.setDname(dname);
	
		BloodBankDAO bloodbank= new BloodBankDAO();
		boolean flag=bloodbank.donationRequest(blood);
		if (flag) {
		response.sendRedirect("DonorHome.jsp?status=Donation Request Accepted");
           } 
		else {
			
		response.sendRedirect("DonorHome.jsp?status=Donation Request Rejected");
		}
	
		

	}
	}


