package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.AwarenessCampBean;
import com.kws.bloodbank.dao.AwarenessCampDAO;

public class PostAwarenessCampServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
              
		System.out.println("im in doPost of PostAwarenessCampServlet");
	    String timing=request.getParameter("morning")+" "+"to"+" "+request.getParameter("evening");
	    AwarenessCampBean camp =new AwarenessCampBean();
		camp.setAcname(request.getParameter("acname"));
		camp.setAcdate(request.getParameter("acdate"));
		camp.setActime(timing);
		camp.setAclocation(request.getParameter("aclocation"));
        camp.setAccity(request.getParameter("accity"));
	    camp.setAcontact(request.getParameter("accontact"));
	    camp.setAcdescription(request.getParameter("acdescription"));
	    camp.setAstatus("pending");
	    HttpSession session=request.getSession();
	    Integer i=(Integer)session.getAttribute("userid");
	    int k=i.intValue();
	    camp.setAcinchargeid(k);
	    camp.setAcadress(request.getParameter("acadress"));
	    System.out.println("values sucessfully set in PostAwarenessCampServlet");
	    boolean flag=new AwarenessCampDAO().postAwarenessCamp(camp);
	    if(flag)
	    {
	    	response.sendRedirect("PostAwarenessCamps.jsp?status=post sucessful");
	    }
	    else
	    {
	    	response.sendRedirect("PostAwarenessCamps.jsp?status=post failure");
	    }
		
		
		
		
		
		
		
		

	}

}
