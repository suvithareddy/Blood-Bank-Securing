package com.kws.bloodbank.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kws.bloodbank.bean.HospitalBean;
import com.kws.bloodbank.dao.BloodBankDAO;
import com.kws.bloodbank.dao.HospitaDAO;

public class HospitalBloodRequestServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}
   public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		HttpSession session=request.getSession();
		String recipientName=(String)(session.getAttribute("user"));
		int recipientid=(Integer)(session.getAttribute("userid"));
		String bloodgroup=request.getParameter("bloodgroup");
		int hid=Integer.parseInt(request.getParameter("hospital"));
		HospitalBean hospital=new HospitalBean();
		hospital.setRname(recipientName);
		hospital.setRid(recipientid);
		hospital.setBloodGroup(bloodgroup);
		hospital.setHid(hid);
		String target=null;
		HospitaDAO hospitalDAO=new HospitaDAO();		
	boolean flag =hospitalDAO.postBloodRequest(hospital);
		if(flag)
		
			 response.sendRedirect("RecipientHome.jsp?status=Request posted sucessfully");
		else
			response.sendRedirect("RecipientHome.jsp?status=Request posting failure");
		
	//request.getRequestDispatcher(target).forward(request, response);
		
		
		 
		
	   
	}

}
