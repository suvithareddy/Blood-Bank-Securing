package Beans;
import java.sql.*;
import java.util.*;
public class DB
{
public static final String DriverClass="oracle.jdbc.driver.OracleDriver";
public static final String dburl="jdbc:oracle:thin:@localhost:1521:XE";
}