package com.kws.bloodbank.dao;
import java.sql.Connection;
import com.kws.bloodbank.bean.HospitalBean;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.kws.bloodbank.bean.BloodBankBean;
import javax.xml.registry.infomodel.EmailAddress;
import com.kws.bloodbank.core.util.DateWrapper;
import com.kws.bloodbank.core.util.LoggerManager;
import com.kws.bloodbank.bean.UserMasterBean;
import com.kws.bloodbank.core.util.DataObject;
import com.kws.bloodbank.core.dao.AbstractDataAccessObject;
//import com.sun.java_cup.internal.emit;
public class UserMasterDAO extends AbstractDataAccessObject{
    Connection con=null;
	PreparedStatement ps=null;
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	PreparedStatement pst2=null;
	PreparedStatement pst3=null;
	PreparedStatement pst4=null;
	PreparedStatement pst5=null;
    PreparedStatement pst6=null;
	Statement st=null;
	Statement st1=null;
	public UserMasterDAO()
	 {
		
		con=getConnection();
		System.out.println("Connection established");
	 }
	    
	//Register User--------------------------------------------
	 
	 
  public boolean registerUser(UserMasterBean userMasterBean){
	  boolean flag=false;
	  
	 
		   int userid=0;
		   String username=userMasterBean.getUsername();
		   String password=userMasterBean.getPassword();
		   String type=userMasterBean.getType();
		   String status=userMasterBean.getStatus();
		   String firstname=userMasterBean.getFirstname();
		   String lastname=userMasterBean.getLastname();
		   String dob=DateWrapper.parseDate(userMasterBean.getDob());
		   String gender=userMasterBean.getGender();
		   String bloodgroup=userMasterBean.getBloodgroup();
		   String location=userMasterBean.getLocation();
		   String city=userMasterBean.getCity();
		   String state=userMasterBean.getState();
		   String contactno=userMasterBean.getContactno();
		   String pin=userMasterBean.getPin();
		   String email=userMasterBean.getEmail();
		   String adress=userMasterBean.getAdress();
		   String securityques=userMasterBean.getSecurityques();
		   String securityans=userMasterBean.getSecurityans();
		   String alloted="no";
		   System.out.println("All values sucessfully got from the bean object in registeruser method in UserMasterDAO");
		   
		   try
		   {
		/*	   System.out.println("i am in try");
		   Statement st = con.createStatement();
		   System.out.println("Statement created");
			ResultSet rs = st.executeQuery("select max(userid) from  usermaster ");
			
		f(rs.next())
		userid = rs.getInt(1);	
		userid++;
		System.out.println("user id prepared userid is "+userid);
	    */
	    con.setAutoCommit(false);
        userid=getSequenceID("usermaster", "userid");
		pst1=con.prepareStatement("insert into usermaster values(?,?,?,?,?,?)");
		pst1.setInt(1,userid);
		pst1.setString(2,username);
		pst1.setString(3,password);
		pst1.setString(4,type);
		pst1.setString(5,status);
		pst1.setString(6,alloted);
		int i=pst1.executeUpdate();
		System.out.println("hi guys i executed the first prepared Statement");
		System.out.println("no of rows updated"+i);
		if(i!=0)
		{
			flag=true;
			System.out.println("pst1 is sucessfuly executed in UserMasterDAO.java");
			pst2=con.prepareStatement("insert into userdetails values(?,?,?,sysdate,?,?,?,?,?,?,?,?,?,?)");
			pst2.setInt(1, userid);
			pst2.setString(2,firstname );
			pst2.setString(3,lastname );
			pst2.setString(4,dob);
			pst2.setString(5,gender);
			pst2.setString(6,bloodgroup);
			pst2.setString(7,location);
			pst2.setString(8,city);
			pst2.setString(9,state);
			pst2.setString(10,contactno);
			pst2.setString(11,pin);
			pst2.setString(12,email);
			pst2.setString(13,adress);
			int j=pst2.executeUpdate();
			System.out.println("hi guys i executed the second prepared Statement");
            System.out.println();
			if(j!=0)
			{
			  flag=true;
			  System.out.println("pst2 is sucessfuly executed in UserMasterDAO.java");
			  pst3=con.prepareStatement("insert into usersecurity values(?,?,?)");
			  pst3.setInt(1, userid);
			  pst3.setString(2,securityques );
			  pst3.setString(3,securityans );
	          int k=pst3.executeUpdate();
			if(k!=0)
			{
			 flag=true;
			 System.out.println("hi guys i executed the pst3 prepared Statement");
				con.commit();
			}
	     }
				else
					
				{
					flag=false;
					con.rollback();
					
				}
				
		}
			
		else
		{
			flag=false;
			con.rollback();
		}
		
		
		  }// end of try
		   
		     catch (SQLException sqlex) {
			   
		    	 LoggerManager.writeLogSevere(sqlex);
		    	 flag=false;
		    	 try
		    	 {
		    	 con.rollback();
		    	 }catch (Exception e) {
		    		 
					System.out.println(e);
				      }
		   }//catch
		     
		System.out.println("i am returning flag in registerUser(UserMasterBean userMasterBean) in UserMasterDAO ");
		
		return flag;
  }
  
  
  
  public ArrayList<UserMasterBean> getPendingRequests(String user){
	  ArrayList<UserMasterBean> pendingList=new ArrayList<UserMasterBean>();
	  try{
		  //con=getConnection();
		  pst4=con.prepareStatement("select userid,username,status from usermaster where logintype=? and status='pending'");
		  UserMasterBean userMasterBean=null;
		  pst4.setString(1,user);
		  ResultSet rs=pst4.executeQuery();
		  while(rs.next()){
			  userMasterBean=new UserMasterBean();
			  System.out.println(rs.getInt(1));
			  userMasterBean.setUserid(rs.getInt(1));
			  userMasterBean.setUsername(rs.getString(2));
			  userMasterBean.setStatus(rs.getString(3));
			  userMasterBean.setType(user);
			  pendingList.add(userMasterBean);
		  }
	  }catch (Exception e) {
		  e.printStackTrace();
		// TODO: handle exception
	}
	  return pendingList;
  }
  public boolean processRequest(int userid){
	  boolean flag=false;
System.out.println("i am in process request");
	   try{
		   ps=con.prepareStatement("update usermaster set status=? where userid=?");
		   ps.setString(1,"completed");
		   ps.setInt(2,userid);
		   int count=ps.executeUpdate();
		   if(count>0)
			    flag=true;
	   }catch (Exception e) {
		   e.printStackTrace();
		// TODO: handle exception
	}
	  return flag;
  }
        
  public int getUserId(String username, String password)
      {
    	  int userid=0;
    	  try
    	  {
	System.out.println("getUserId-con check");
    		  st1=con.createStatement();
		System.out.println("getUserId-con ok");
  			  ResultSet rs=st1.executeQuery("select userid from usermaster where username='"+username+"' and password='"+password+"'");  
    		  
		while(rs.next())
    		  {
    			userid=rs.getInt(1);
    		  }
    	  }catch (Exception e)
    	  {
			e.printStackTrace();
			}
    	  return userid;
      }
  
   
   public ArrayList<UserMasterBean> getVolunteerList(){
	   ArrayList<UserMasterBean> volunteerList=new ArrayList<UserMasterBean>();
	   try{
		   UserMasterBean userMasterBean=null;
		   st=con.createStatement();
		  ResultSet rs=st.executeQuery("select userid,username,alloted from usermaster where logintype='volunteer'");
		  while(rs.next()){
			  userMasterBean=new UserMasterBean();
			  userMasterBean.setUserid(rs.getInt(1));
			  userMasterBean.setUsername(rs.getString(2));
			  userMasterBean.setAvailable(rs.getString(3));
			  volunteerList.add(userMasterBean);
		  }
	   }catch (Exception e) {
		   e.printStackTrace();
		// TODO: handle exception
	}
	   return volunteerList;
   }
   public ArrayList<UserMasterBean> getProfile(String type)
   {
	   ArrayList<UserMasterBean> profileList=new ArrayList<UserMasterBean>();
	   try
	   {
		   
 pst=con.prepareStatement("select ud.firstname,ud.lastname,ud.DOB,ud.dor,ud.gender,ud.bloodgroup,ud.location, ud.city, ud.state,ud.contactno,ud.pin,ud.email,ud.adress,u.username,u.userid,u.password from userdetails ud, usermaster u where u.logintype=? and u.userid=ud.userid");
 pst.setString(1,type);
		   ResultSet rs=pst.executeQuery();
		   while(rs.next())
		   {
			    UserMasterBean userMasterBean=new UserMasterBean();
			    userMasterBean.setFirstname(rs.getString(1));
			    userMasterBean.setLastname(rs.getString(2));
			    userMasterBean.setDob(DateWrapper.parseDate(rs.getDate(3)));
			    userMasterBean.setDor(rs.getString(4));
			    userMasterBean.setGender(rs.getString(5));
			    userMasterBean.setBloodgroup(rs.getString(6));
			    userMasterBean.setLocation(rs.getString(7));
			    userMasterBean.setCity(rs.getString(8));
			    userMasterBean.setState(rs.getString(9));
			    userMasterBean.setContactno(rs.getString(10));
			    userMasterBean.setPin(rs.getString(11));
			    userMasterBean.setEmail(rs.getString(12));
			    userMasterBean.setAdress(rs.getString(13));
			    userMasterBean.setUsername(rs.getString(14));
			    userMasterBean.setUserid(rs.getInt(15));
			    userMasterBean.setPassword(rs.getString(16));
			    
			   profileList.add(userMasterBean);
		   }
	   }catch (Exception e) {
		   
		   e.printStackTrace();
		// TODO: handle exception
	}
	   return profileList;
	   
   }
   
   
   public  UserMasterBean getDonor(String  username)
   {
	 UserMasterBean userMasterBean=new UserMasterBean();
	 String donorname=username.trim();
	 try
	 {
		 PreparedStatement pst=con.prepareStatement("select userid from usermaster where username=?");
		 pst.setString(1,donorname);
		 ResultSet rs=pst.executeQuery();
		 while(rs.next())
		{
		  userMasterBean.setUserid(rs.getInt("userid"));
		}
      }
	    catch (Exception e)
	   {
		  e.printStackTrace();
        }
	  return userMasterBean;
    }
     public ArrayList<UserMasterBean> getUserList()
     {
    	 ArrayList<UserMasterBean> userList=new ArrayList<UserMasterBean>();
    	 try
    	 {
    		 st=con.createStatement();
    		 ResultSet rs=st.executeQuery("select *  from usermaster");
    		 while(rs.next())
    		 {
    			 UserMasterBean user=new UserMasterBean();
    			 user.setUserid(rs.getInt(1));
    			 user.setUsername(rs.getString(2));
    			 user.setPassword(rs.getString(3));
    			 user.setType(rs.getString(4));
    			 user.setStatus(rs.getString(5));
    			 userList.add(user);
    		 }
    		 
    		 
    	 }catch (Exception e) {
			e.printStackTrace();
    		 // TODO: handle exception
		}
    	 return userList;
	   
      }
     
     
     
     public ArrayList<UserMasterBean> getUsers(String bloodgroup)
     {
  	   ArrayList<UserMasterBean> profileList=new ArrayList<UserMasterBean>();
  	   try
  	   {
  		   
   pst=con.prepareStatement("select location from userdetails  where bloodgroup=?");
   pst.setString(1,bloodgroup);
  		   ResultSet rs=pst.executeQuery();
  		   while(rs.next())
  		   {
  			    UserMasterBean userMasterBean=new UserMasterBean();
  			    userMasterBean.setLocation(rs.getString(1));
  			   System.out.println(rs.getString(1));
  			    profileList.add(userMasterBean);
  		   }
  	   }catch (Exception e) {
  		   
  		   e.printStackTrace();
  		// TODO: handle exception
  	}
  	   return profileList;
  	   
     }
    
     
     
     public ArrayList<UserMasterBean> getInfo(String bloodgroup,String location) 
     {
  	   ArrayList<UserMasterBean> DList=new ArrayList<UserMasterBean>();
  	   try
  	   {
  		   
   pst=con.prepareStatement("select firstname,lastname,city,state,contactno,adress from userdetails where bloodgroup=? and location=?");
   pst.setString(1,bloodgroup);
   pst.setString(2,location);
  		   ResultSet rs=pst.executeQuery();
  		   while(rs.next())
  		   {
  			    UserMasterBean userMasterBean=new UserMasterBean();
  			    userMasterBean.setFirstname(rs.getString(1));
  			    userMasterBean.setLastname(rs.getString(2));
  			    userMasterBean.setLocation(location);
  			    userMasterBean.setCity(rs.getString(3));
  			    userMasterBean.setState(rs.getString(4));
  			    userMasterBean.setContactno(rs.getString(5));
  			    userMasterBean.setAdress(rs.getString(6));
  			    DList.add(userMasterBean);
  		   }
  	   }catch (Exception e) {
  		   
  		   e.printStackTrace();
  		// TODO: handle exception
  	}
  	   return DList;
  	   
     }
     
   public String forgotPassword(UserMasterBean userMasterBean)
   {
	   boolean flag=false;
	   String password=null;
	   String username=userMasterBean.getUsername();
	   try {
		   pst=con.prepareStatement("select userid from usersecurity where SECURITYQUES=? and SECURITYANS=?");
		   pst.setString(1,userMasterBean.getSecurityques());
		   pst.setString(2,userMasterBean.getSecurityans());
		   ResultSet rs=pst.executeQuery();
		   int count=0;
		   int[] userid;              // declares an array of integers

	          userid= new int[10];
		 
		   while(rs.next())
		   {
			  userid[count]=rs.getInt(1);
			  System.out.println(userid[count]);
			  count++; 
			 
		   }
		   System.out.println(count);
		   for(int i:userid)
		   {
			   pst1=con.prepareStatement("select password from usermaster where username=? and userid=?");
    	       pst1.setString(1,username);
                pst1.setInt(2,i);
    	        ResultSet rs1=pst1.executeQuery();
    	       while(rs1.next())
    	       {
    		     password=rs1.getString(1);
    		     System.out.println(password);
    		     break;
    		    }
    	       if(password!=null)
    	    	   break;
		   }
		   
		   
		   
		    
		    
		
	} catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	  return password;
   }
   }



