//LOAD DEFAULTS FOR VARIABLES WE HAVE ADDED SINCE VERSION 1 OF THE PORTAL

//******* DEPRECATED VARIABLES - left for compatability ************//
if(typeof(SB_LOGOUT_LINK_TEXT) == 'undefined')
	var SB_LOGOUT_LINK_TEXT = "";

if(typeof(SB_BORDER) == 'undefined')
	var SB_BORDER = "0";

if(typeof(SB_BORDER_COLOR) == 'undefined')
	var SB_BORDER_COLOR = "#000000";

if(typeof(SB_PADDING) == 'undefined')
	var SB_PADDING = "0";
//******* END DEPRECATED VARIABLES ************//
// This prevents users of older code from getting javascript errors
//if (typeof variableName == 'undefined')
if (typeof(SB_MAX_STORIES_PER_SECTION) == 'undefined')
	var SB_MAX_STORIES_PER_SECTION = 1000;

if (typeof(SB_MAX_STORIES_TOTAL) == 'undefined')
	var SB_MAX_STORIES_TOTAL = 1000;

if (typeof(SB_EMAIL_COOKIE_NAME) == 'undefined')
	var SB_EMAIL_COOKIE_NAME = "";

if (typeof(issue) == 'undefined')
	var issue = null;

if(typeof(SB_FOOTER_GRAPHIC_ALIGN) == 'undefined')
	var SB_FOOTER_GRAPHIC_ALIGN = "right";

if (typeof(SB_PORTAL_ID) == 'undefined')
	var SB_PORTAL_ID = "";

if (typeof(SB_ALLOW_LOGIN) == 'undefined')
	var SB_ALLOW_LOGIN = false;

if (typeof(SB_SERVER) == 'undefined')
{
		var SB_SERVER = "http://www.smartbrief.com";
}

if (typeof(SB_STORY_SPACER_HEIGHT) == 'undefined')
	var SB_STORY_SPACER_HEIGHT = 5;

//top story vars
if (typeof(SB_TOPSTORY_SHOW_SOURCES) == 'undefined')
	var SB_TOPSTORY_SHOW_SOURCES = true;

if (typeof(SB_TOPSTORY_SHOW_FOOTER) == 'undefined')
	var SB_TOPSTORY_SHOW_FOOTER = false;

//we originally mis-named SB_DATE_CLASS as SB_SECTION_DATE_CLASS - we fixed it but don't want to force all end users to correct it, so this will make the current portal javascript compatible with their options list
if (typeof(SB_DATE_CLASS) == 'undefined')
{
	if(typeof(SB_SECTION_DATE_CLASS) != 'undefined' )
		var SB_DATE_CLASS = SB_SECTION_DATE_CLASS;
	else
		var SB_DATE_CLASS = "";
}

//END LOAD DEFAULTS
if(typeof(SB_CAMPAIGN) == 'undefined')
	var SB_CAMPAIGN = SB_BRIEF_NAME +" Headlines";

var SB_LINK = SB_SERVER + "/subscriber/view_story.jsp?campaign="+SB_CAMPAIGN;
if(!SB_ALLOW_LOGIN)
{
	SB_LINK = SB_SERVER + "/subscriber/view_story.jsp?campaign="+SB_CAMPAIGN;
}
if(SB_EMAIL_COOKIE_NAME!="")
{
	var SB_EMAIL = getCookie(SB_EMAIL_COOKIE_NAME);
	if(SB_EMAIL!=null)
		SB_LINK += "username="+SB_EMAIL+"&";
}

var SB_SIGNUP_URL = SB_SERVER + "/"+SB_BRIEF_NAME.toLowerCase()+"?campaign="+SB_CAMPAIGN+"%20SignupLink";
var SB_LOGOUT_URL = SB_SERVER + "/subscriber/logout.jsp";
if (typeof(SB_FOOTER_GRAPHIC) == 'undefined')
	var SB_FOOTER_GRAPHIC = SB_SERVER + "/images/xml/generic/poweredby_sb.gif";
if (typeof(SB_FOOTER_GRAPHIC_WIDTH) == 'undefined')
	var SB_FOOTER_GRAPHIC_WIDTH = "130";
if (typeof(SB_FOOTER_GRAPHIC_HEIGHT) == 'undefined')
	var SB_FOOTER_GRAPHIC_HEIGHT = "20";
var sections = new Array();
var stories;

function SBLink()
{
   this.id;
   this.source;
   this.url;
   this.date;
   this.attribution;
   this.condition;
}

function SBLink(id, source, url, date, attr, condition)
{
   this.id = id;
   this.source = source;
   this.url = url;
   this.date = date;
   this.attribution = attr;
   this.condition = condition;
}

function SBStory()
{
   this.headline ;
   this.copyid;
   //this.source ;
   this.link;
}

function SBStory( h, cid, l, copy)
{
   this.headline = h;
   this.copyid = cid;
   //this.source = src;
	if(typeof(l)=="String") //we passed a single link
	{
		this.link=l;
	}
	else //we passed an array of links
	{
		this.links=l;
	}
   this.link = l;
   this.copy = copy;
}

function SBStory( h, cid, l, copy, parentid)
{
   this.headline = h;
   this.copyid = cid;
   //this.source = src;
	if(typeof(l)=="String") //we passed a single link
	{
		this.link=l;
	}
	else //we passed an array of links
	{
		this.links=l;
	}
   this.link = l;
   this.copy = copy;
   this.parentid = parentid;
}

function SBSection()
{
	this.id;
	this.name;
	this.link;
	this.stories;
}
function SBSection( id, n, l, s )
{
	this.id = id;
	this.name = n;
	this.link = l ;
	this.stories = s;
}
function SBIssue( dt, briefid, issueid, style, fullbriefname )
{

	this.date = dt;
	this.brief= briefid;
	this.id = issueid;
	this.style = style;
	this.fullbriefname = fullbriefname;
}

function SBTopStory( briefid, issueid, style, fullbriefname, story )
{

	//issue vars
	this.brief= briefid;
	this.id = issueid;
	this.style = style;
	this.fullbriefname = fullbriefname;
	this.story = story; //SBStory() object
}

function getCookie(name)
{
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1)
	{
		begin = dc.indexOf(prefix);
		if (begin != 0)
			return null;
	}
	else
	{
		begin += 2;
	}
	var end = document.cookie.indexOf(";", begin);
	if (end == -1)
		end = dc.length;
	return unescape(dc.substring(begin + prefix.length, end));
}