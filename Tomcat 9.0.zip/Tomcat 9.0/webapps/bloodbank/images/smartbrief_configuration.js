			<!-- Begin SmartBrief Options -->
			//GENERAL VARIABLS - provided to end user by SmartBrief, Inc.
			var SB_PORTAL_ID = "6503"; //sets id for logging and registration purposes; required - get this from SmartBrief
			var SB_BRIEF_NAME = "AABB"; //sets briefname variable for urls - get this from SmartBrief
			var SB_SERVER = "http://www.smartbrief.com"; //http://www.smartbrief.com or http://www.dailylead.com
			var SB_STYLE = "sb"; //dl=daily lead, sb=smartbrief
			var SB_EMAIL_COOKIE_NAME = "xml_email";
			var SB_FOOTER_GRAPHIC = "";

			//CLASS VARIABLES - if you have already developed CSS styles for your website,
			// you can assign them to the various parts of the SmartBrief content portal
			// Otherwise, leave these variables untouched and revise the styles in sb_styles.css to change the various font styles
			var SB_HEADLINE_CLASS = "WhatsNew-Links"; //sets css class for headline text links
			var SB_COPY_CLASS = "sb_copy"; //sets css class for headline text links
			var SB_LINK_CLASS = "WhatsNew-Links"; //sets css class for headline text links
			var SB_SECTION_NAME_CLASS = "sb_sectionname"; //sets css class for section name text
			var SB_DATE_CLASS = "SmartBrief-Date"; //sets css class for portal date text

			//LOOK AND FEEL
			var SB_BACKGROUND_COLOR = "#FFFFFF"; //sets background color for headline portal
			var SB_PADDING = "7"; //padding
			var SB_BORDER = 0; // sets border width for headline portal (0 = no border)
			var SB_BORDER_COLOR = "#666699";
			var SB_INFO_TEXT = "";//"Sign up for breaking news in the search for cures";
			var SB_INFO_CLASS= "InlineNewsBanner";
			var SB_BULLET = "../Images/bullet.gif";
			var SB_BULLET_HEIGHT = "6";
			var SB_BULLET_WIDTH = "6";
			var SB_SIGNUP_LINK_TEXT = "Sign Up Now";
			var SB_ISSUE_LINK_TEXT = "View Current Issue";
			var SB_WIDTH = "200"; //sets width of headline portal table - note that this includes the entire width of the portal, outside-to-outside
			var SB_SECTION_SPACER_HEIGHT = "3"; //vertical spacing b/n sections
			var SB_STORY_SPACER_HEIGHT = "3"; //vertical spacing b/n stories

			//ADVANCED VARIABLES - you can remove or leave as-is unless instructed otherwise by SmartBrief, Inc.

			//var SB_REQUIRE_LOGIN = false;

			var SB_SHOW_SECTION_NAME = false; //true/false - you can suppress the section name if you are only displaying one section's content
			
			<!-- End SmartBrief Options -->