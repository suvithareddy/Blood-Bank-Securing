		/* let's stick some recurring lines into strings for later use */
		var SB_STORY_SPACER = "";
		if(SB_STORY_SPACER_HEIGHT>0)
		{
			//spacer row b/n info text and first headline
			SB_STORY_SPACER += "\<tr\>";
			if(SB_BORDER > 0) { SB_STORY_SPACER += "\<td width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" height='"+SB_STORY_SPACER_HEIGHT+"' width='"+SB_BORDER+"'\>\</td\>"; }
			SB_STORY_SPACER += "\<td colspan='3' bgcolor='"+SB_BACKGROUND_COLOR+"' align='left'\>\<img src='http://www.smartbrief.com/images/shim.gif' height='"+SB_STORY_SPACER_HEIGHT+"' width='1'\></td\>";
			if(SB_BORDER > 0) { SB_STORY_SPACER += "\<td width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" height='"+SB_STORY_SPACER_HEIGHT+"' width='"+SB_BORDER+"'\>\</td\>"; }
			SB_STORY_SPACER += "\</tr\>";
		}

		var SB_SECTION_SPACER = "";
		if(SB_SECTION_SPACER_HEIGHT>0)
		{
			//spacer row b/n info text and first headline
			SB_SECTION_SPACER += "\<tr\>";
			if(SB_BORDER > 0) { SB_SECTION_SPACER += "\<td width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" height='"+SB_SECTION_SPACER_HEIGHT+"' width='"+SB_BORDER+"'\>\</td\>"; }
			SB_SECTION_SPACER += "\<td colspan='3' bgcolor='"+SB_BACKGROUND_COLOR+"' align='left'\>\<img src='http://www.smartbrief.com/images/shim.gif' height='"+SB_SECTION_SPACER_HEIGHT+"' width='1'\></td\>";
			if(SB_BORDER > 0) { SB_SECTION_SPACER += "\<td width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" height='"+SB_SECTION_SPACER_HEIGHT+"' width='"+SB_BORDER+"'\>\</td\>"; }
			SB_SECTION_SPACER += "\</tr\>";
		}
		/* Portal Output Commands */
		//document.write("<!-- BEGIN SMARTBRIEF NEWS PORTAL -->");
		document.write("\<table width='"+SB_WIDTH+"' cellpadding='0' cellspacing='0' border='0' bgcolor='"+SB_BACKGROUND_COLOR+"'\>");
		//portal border
		if(SB_BORDER > 0)
		{
			document.write("\<tr\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_PADDING+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_PADDING+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_PADDING+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_PADDING+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
			document.write("\</tr\>");
		}
		//padding
		if(SB_PADDING>0)
		{
			document.write("\<tr\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\<td width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='1' height='"+SB_PADDING+"'\>\</td\>");
				document.write("\<td width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\></td\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\</tr\>");
		}

		//updated date
		if(issue!=null && sections.length>0)
		{
			document.write("\<tr\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\<td width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\</td\>");
				document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"' nowrap='yes' align='left'\>\<font class='"+SB_DATE_CLASS+"'\>Updated "+issue.date+"\</font\>\</td\>");
				document.write("\<td width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\></td\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\</tr\>");
		}

		document.write(SB_SECTION_SPACER);

		//write the smartbrief info pitch
		if(SB_INFO_TEXT != "")
		{
			document.write("\<tr\>");
			if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\<TD width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\</TD\>");
			document.write("\<TD bgcolor='"+SB_BACKGROUND_COLOR+"'\>\<FONT class='"+SB_INFO_CLASS+"'\>"+SB_INFO_TEXT+"&nbsp;&nbsp;\</FONT\>\</TD\>");
			document.write("\<TD width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\</TD\>");
			if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\</tr\>");

			document.write(SB_SECTION_SPACER);
		}

		//print sections/stories
		if(issue!=null && sections.length>0)
		{
			document.write(SB_SECTION_SPACER);
			var j=0;
			var storyNo=0;
			while(j<sections.length)
			{
				if(j>0)
				{
					document.write(SB_SECTION_SPACER);
				}
				if(SB_SHOW_SECTION_NAME)
				{
					//section info
					document.write("\<tr\>");
						if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
						document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"' width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
						document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"'\>\<font class='"+SB_SECTION_NAME_CLASS+"'\>"+sections[j].name+"\</font\>\</td\>");
						document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"' width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
						if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
					document.write("\</tr\>");
				}

				stories = sections[j].stories;
				//print stories
				var i = 0;
				while(i<stories.length && storyNo<SB_MAX_STORIES_PER_SECTION && storyNo<SB_MAX_STORIES_TOTAL)
				{
					storyNo++;
					document.write("\<tr\>");
					if(SB_BORDER > 0) { document.write("\<td width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\</td\>"); }
					document.write("\<td height='"+SB_PADDING+"' width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" >\</td\>");
					document.write("\<td valign='top' bgcolor='"+SB_BACKGROUND_COLOR+"'\>");
					if(SB_BULLET)
					{
						document.write("\<img src='"+SB_BULLET+"' height='"+SB_BULLET_HEIGHT+"' width='"+SB_BULLET_WIDTH+"' border='0'\>");
						document.write("\<img src='http://www.smartbrief.com/images/shim.gif' height='1' width='2'\>");
					}
					var story_url = SB_LINK+"&copyid="+stories[i].copyid+"&issueid="+issue.id+"&style="+issue.style
					var linkHref = SB_SERVER + "/servlet/rdrc?u="+escape(story_url)+"&i="+issue.id+"&p="+SB_PORTAL_ID;
					document.write("\<a TARGET='_blank' class='"+SB_HEADLINE_CLASS+"' href='"+linkHref+"'\>"+stories[i].headline+"\</a\>");
					document.write("\</td\>");
					document.write("\<td height='"+SB_PADDING+"' width='"+SB_PADDING+"' bgcolor='"+SB_BACKGROUND_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" >\</td\>");
					if(SB_BORDER > 0) { document.write("\<td width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\</td\>"); }
					document.write("\</tr\>");
					document.write(SB_STORY_SPACER);
					i++;
				}//end while (stories)
				j++;
			} //end for(j< sections.length)
		} //end if(sections.length>0)
		else
		{
			document.write("\<tr\>");
				if(SB_BORDER > 0) { document.write("\<td height='40' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"' height='40' width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
			document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"' height='40' valign='middle'\>\<font class='"+SB_DATE_CLASS+"'\>These headlines are currently unavailable. Please check back later.</font\>\</td\>");
			document.write("\<td bgcolor='"+SB_BACKGROUND_COLOR+"' height='40' width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
				if(SB_BORDER > 0) { document.write("\<td height='40' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\</tr\>");
		}

		var xml_lmid = getCookie("xml_lmid");
		if(xml_lmid!=null && xml_lmid!="" && xml_lmid!="null")
		{
			if(SB_LOGOUT_LINK_TEXT!="")
			{
				//write the logout link
				document.write("\<tr\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\<td width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
				document.write("\<TD align='right' bgcolor='"+SB_BACKGROUND_COLOR+"'\><A class='"+SB_LINK_CLASS+"' target='_blank' href='"+SB_LOGOUT_URL+"'\>"+SB_LOGOUT_LINK_TEXT+"\</A\></TD\>");
				document.write("\<td width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\</tr\>");
			}
		}
		else
		{
			if(SB_SIGNUP_LINK_TEXT!="")
			{
				//write the signup link
				document.write("\<tr\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\<td width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
				document.write("\<TD align='right' bgcolor='"+SB_BACKGROUND_COLOR+"'\><A class='"+SB_LINK_CLASS+"' target='_blank' href='"+SB_SIGNUP_URL+"'\>"+SB_SIGNUP_LINK_TEXT+"\</A\></TD\>");
				document.write("\<td width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\</tr\>");
			}
		}

		//write the current issue link
		if(issue!=null && SB_ISSUE_LINK_TEXT!="")
		{
			document.write("\<tr\>");
			if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\<td width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
			document.write("\<TD align='right' bgcolor='"+SB_BACKGROUND_COLOR+"'\><A class='"+SB_LINK_CLASS+"' target='_blank' href='"+SB_LINK+"&issueid="+issue.id+"'\>"+SB_ISSUE_LINK_TEXT+"\</A\></TD\>");
			document.write("\<td width='"+SB_PADDING+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>");
			if(SB_BORDER > 0) { document.write("\<td height='"+SB_PADDING+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\</tr\>");
		}

		/*
		if(SB_BORDER > 0)
		{
			document.write("\<tr\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='5' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='5' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='5' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='5' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
			document.write("\</tr\>");
		}
		*/
		if(issue!=null && SB_FOOTER_GRAPHIC != "")
		{
			document.write("\<tr\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
				document.write("\<td colspan='3' bgcolor='"+SB_BACKGROUND_COLOR+"' align='"+SB_FOOTER_GRAPHIC_ALIGN+"'\>\<a target='_blank' href='"+SB_SIGNUP_URL+"'\>\<img alt='Sign up for '"+issue.fullbriefname+"' border='0' src='"+SB_FOOTER_GRAPHIC+"' height='"+SB_FOOTER_GRAPHIC_HEIGHT+"' width='"+SB_FOOTER_GRAPHIC_WIDTH+"'\>\</a\>\</td\>");
				if(SB_BORDER > 0) { document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("\</tr\>");
		}

		//call rdro to log open
		/*
		var rdrHref = SB_SERVER + "/servlet/rdro?i="+issue.id+"&p="+SB_PORTAL_ID;
		document.write("\<tr\>");
			if(SB_BORDER > 0) { document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
			document.write("<td colspan='3' nowrap='yes' width='100%'><img height='1' width='1' src='"+rdrHref+"'</font></td>");
			//document.write("\<td colspan='3' bgcolor='"+SB_BACKGROUND_COLOR+"' align='right'\></td\>");
			if(SB_BORDER > 0) { document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"'\>\</td\>"); }
		document.write("\</tr\>");
		*/
		if(SB_BORDER > 0)
		{
			document.write("\<tr\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_PADDING+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_PADDING+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_PADDING+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_PADDING+"' height='"+SB_BORDER+"'\>\</td\>");
				document.write("\<td height='"+SB_BORDER+"' width='"+SB_BORDER+"' bgcolor='"+SB_BORDER_COLOR+"'\>\<img src=\"http:\/\/www.smartbrief.com\/images\/shim.gif\" width='"+SB_BORDER+"' height='"+SB_BORDER+"'\>\</td\>");
			document.write("\</tr\>");
		}
		document.write("\</table\>");
		//document.write("<!-- END SMARTBRIEF NEWS PORTAL -->");