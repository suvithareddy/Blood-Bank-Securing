var count = 0;
var RotateTime;
var Feature = 1; // Feature to rotate 1 = Main  2 = Middle  3 = both

function MessageCycle(len){this.length=len;} 

MessageMain = new MessageCycle(2);
MessageMain[0] ="<IMG border='0' src='joint_ie/img_temp.jpg' width='475' height='141' >";
MessageMain[1] ="<IMG border='0' src='joint_ie/img_temp1.jpg' width='475' height='141' >" ;
MessageMain[2] ="<IMG border='0' src='joint_ie/img_temp2.jpg' width='475' height='141' >" ;
MessageMain[3] ="<IMG border='0' src='joint_ie/img_temp3.jpg' width='475' height='141' >" ;

function RotateMessage(){
    if ((typeof(Main1.innerHTML) != "undefined") ||  (typeof(Middle1.innerHTML) != "undefined"))
	{
		var rotest = navigator.userAgent;
		if (count == 3) { count = 0; } else { count++; }
		if ((Feature == 1) || (Feature == 3)) {
			if ((i = rotest.indexOf("MSIE"))>= 0) {
				Main1.filters[0].apply();
				Main1.innerHTML = MessageMain[count];       
				Main1.filters[0].play();  
			}
			else
			{
				Main1.innerHTML = MessageMain[count];
			}
		}
		if ((Feature == 2)  || (Feature == 3)) {
			if ((i = rotest.indexOf("MSIE"))>= 0) {
				Middle1.filters[0].apply();
				Middle1.innerHTML = MessageMiddle[count];       
				Middle1.filters[0].play(); 
			}
			else
			{
				Middle1.innerHTML = MessageMiddle[count]; 
			}
		}       
	
		if ((Feature == 1) || (Feature == 2)  || (Feature == 3)) {
				RotateTime = setTimeout('RotateMessage()',5000); 
		}      
	}             
}
