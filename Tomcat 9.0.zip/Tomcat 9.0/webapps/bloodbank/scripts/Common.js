function fnOpen(URL)
{
	window.open(URL,'',"toolbar=0,status=0,menubar=0,fullscreen=no,width=500,height=500,resizable=0");
	//return false;
}

// Allow Only Numbers
function allowOnlyNumbers(evt)
{

	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	{
		alert("Please enter only numbers");
		return false;
	}

	return true;
}
// Allow Only Numbers and hypens
function allowOnlyNumbersAndHypen(evt)
{

	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode != 45))
	{
		alert("Please enter only numbers");
		return false;
	}

	return true;
}

function allowMoreThanZero(cntName)
{
	if(document.getElementById(cntName).value==0)
	{
		alert("Please enter qty more than 0");
		document.getElementById(cntName).focus();
		return false;
	}
	return true;
}

function trimString (str) 
{
	str = this != window? this : str;
	return str.replace(/^\s+/g, '').replace(/\s+$/g, '');
}
	
	
function checkPercentage(cntlr)
{
	var reg = new RegExp(/^100$|^\d{0,2}(\.\d{1,2})? *%?$/);
	if (document.getElementById(cntlr).value.match(reg))
	{
			return true;
	}
	else
	{
		alert("Invalid percentage");
		return false;
	}


}	

function checkDecimal(cntlr)
{
	var reg = new RegExp(/^(\d+|(\d*\.{1}\d{1,2}){1})$/);
	if (document.getElementById(cntlr).value.match(reg))
	{
			return true;
	}
	else
	{
		alert("Invalid Shipping Cost");
		return false;
	}

}	
function ismaxlength(obj){
var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
if (obj.getAttribute && obj.value.length>mlength)
obj.value=obj.value.substring(0,mlength+1)
}


function fnlength(cntNAME,message)
{
	if (cntNAME.value.length>500)
	{
		alert(message);
		cntNAME.focus();
		return false;
	}
	return true;
}


// Enter Key Functionality
	function enterSubmit(btnSubmit) 
	{
		if ((event.which && event.which == 13) || (event.keyCode && event.keyCode == 13))
		{
			document.getElementById(btnSubmit).click();
			return false;
		} 
		else 
			return true;
	}		

  

// End Of Enter Key

// Enter date in mm/dd/yyyy format

var mydate = new Date();
var dtCh= "/";
var minYear=1900;
var maxYear=parseInt(mydate.getFullYear()) + 100;

function isInteger(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this
}

function isDate(dtStr){
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)
	var strMonth=dtStr.substring(0,pos1)
	var strDay=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}
	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)
	if (pos1==-1 || pos2==-1){
		alert("The date format should be : mm/dd/yyyy")
		return false
	}
	if (strMonth.length<1 || month<1 || month>12){
		alert("Please enter a valid month")
		return false
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		alert("Please enter a valid day")
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
		alert("Please enter a valid date")
		return false
	}
return true
}

function enterDateFormat(txtDate){
	var dt=document.getElementById(txtDate);
	if (isDate(dt.value)==false){
		dt.focus()
		return false
	}
    return true
 }


//Ajax
function categoryContent(result, context)
{
    var dropdown2 = document.forms[0].elements['dpDistrict']; 
    dropdown2.innerHTML= "";
    var dropCity = document.forms[0].elements['dpCity']; 
    dropCity.innerHTML= ""; 
    if (result!="")
    {
        var rows = result.split('||'); 
        dropdown2.options[0] = new Option('ALL','0|dpDistrict');
        for (var i = 0; i < rows.length - 1; ++i) 
        { 
            var values = rows[i].split('|');
            var option = document.createElement("OPTION");
            option.value = values[0] + "|dpDistrict"; 
            option.innerHTML = values[1]; 
            dropdown2.appendChild(option); //dpSpecial.options[0] = new Option('Please Select','0'); 
        }
        var dropCity = document.forms[0].elements['dpCity']; 
        dropCity.options[0] = new Option('ALL','0|dpCity');
    }
    else
    {
        dropdown2.options[0] = new Option('ALL','0|dpDistrict');
        var dropCity = document.forms[0].elements['dpCity']; 
        dropCity.options[0] = new Option('ALL','0|dpCity');
    }
    
}
function subCategoryContent(result, context)
{
    var dropdown2 = document.forms[0].elements['dpCity']; 
    dropdown2.innerHTML= ""; 
    var rows = result.split('||');
    dropdown2.options[0] = new Option('ALL','0');
    for (var i = 0; i < rows.length - 1; ++i) 
    { 
        var values = rows[i].split('|');
        var option = document.createElement("OPTION"); 
        option.value = values[0] ;//+ "|dpCity"; 
        option.innerHTML = values[1];     
        dropdown2.appendChild(option); 
    } 
}
function ClientCallbackError()
{
    alert("Got Some Error");
}
//end Of Ajax